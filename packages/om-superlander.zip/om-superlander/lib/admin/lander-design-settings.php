<?php

add_filter( 'genesis_available_sanitizer_filters', 'lander_font_weights_sanitizer' );

function lander_font_weights_sanitizer( $filters ) {
	$filters['lander_font_weight'] = 'lander_sanitize_font_weight';
	return $filters;
}

function lander_sanitize_font_weight($new,$old){
	if(in_array($new,lander_font_weights())) {
		return $new;
	}
	return $old;
}

class Lander_Design_Settings extends Genesis_Admin_Boxes {
	private $lander_fonts;
	function __construct() {
		$page_id            = lander_get_design_page_id();
		$menu_ops           = array(
			 'submenu' => array(
				'parent_slug' => __( 'genesis', CHILD_DOMAIN ),
				'page_title' => sprintf(__( 'Super Lander Design Settings &mdash; &#8220;%s&#8221;', CHILD_DOMAIN ), lander_get_design_page_title()),
				'menu_title' => __( 'Super Lander Design', CHILD_DOMAIN ) 
			) 
		);
		$page_ops           = array(
			'screen_icon' => 'themes',
			'save_button_text' => sprintf(__('Save %s Options',CHILD_DOMAIN),lander_get_design_page_title()),
			'reset_button_text' => sprintf(__('Reset %s To Defaults',CHILD_DOMAIN),lander_get_design_page_title())
		);
		
		$settings_field     = lander_get_design_page_id();
		$this->lander_fonts = lander_get_fonts();
		$this->create( $page_id, $menu_ops, $page_ops, $settings_field, lander_design_defaults() );
		
		add_action( 'admin_print_styles', array(
			 $this,
			'styles' 
		) );
	}	
	
	function sanitization_filters() {
		genesis_add_option_filter( 'absint', CHILD_SETTINGS_FIELD, array(
			'col-spacing',
			'column-content-1col',
			'column-content-2col',
			'sidebar-one-2col',
			'column-content-3col',
			'sidebar-one-3col',
			'sidebar-two-3col',
			'subnav-menu-submenu-width',
			'nav-menu-submenu-width',
			'nav-menu-border-width',
			'subnav-menu-border-width',
			'content-area-font-size',
			'header-area-font-size',
			'header-area-tagline-font-size',
			'headline-font-size',
			'nav-menu-font-size',
			'subnav-menu-font-size',
			'byline-font-size',
			'code-font-size',
			'sidebar-font-size',
			'sidebar-heading-font-size',
			'footer-widgets-font-size',
			'footer-widgets-heading-font-size',
			'footer-font-size'

		) );
		
		genesis_add_option_filter( 'no_html', CHILD_SETTINGS_FIELD, array(
		'site-background-color',
		'page-background-color',
		'primary-text-color',
		'primary-link-color',
		'primary-link-hover-color',
		'header-area-font-color',
		'header-area-tagline-font-color',
		'headline-font-color',
		'headline-subhead-font-color',
		'nav-menu-link-text-color',
		'nav-menu-link-text-hover-color',
		'nav-menu-current-link-text-color',
		'nav-menu-current-parent-link-text-color',
		'nav-menu-link-bg-color',
		'nav-menu-hover-bg-color',
		'nav-menu-current-bg-color',
		'nav-menu-current-parent-bg-color',
		'nav-menu-border-color',
		'subnav-menu-link-text-color',
		'subnav-menu-link-text-hover-color',
		'subnav-menu-current-link-text-color',
		'subnav-menu-current-parent-link-text-color',
		'subnav-menu-link-bg-color',
		'subnav-menu-hover-bg-color',
		'subnav-menu-current-bg-color',
		'subnav-menu-current-parent-bg-color',
		'subnav-menu-border-color',
		'byline-font-color',
		'code-font-color',
		'sidebar-font-color',
		'sidebar-heading-font-color',
		'footer-widgets-font-color',
		'footer-widgets-heading-font-color',
		'footer-font-color',
		'body-font-family',
		'header-area-font-family',
		'header-area-tagline-font-family',
		'headline-font-family',
		'headline-subhead-font-family',
		'nav-menu-font-family',
		'subnav-menu-font-family',
		'byline-font-family',
		'code-font-family',
		'sidebar-font-family',
		'sidebar-heading-font-family',
		'footer-widgets-font-family',
		'footer-widgets-heading-font-family',
		'footer-font-family',
		));
	
		
		genesis_add_option_filter( 'lander_font_weights_sanitizer', CHILD_SETTINGS_FIELD, array(
		'content-area-font-weight',
		'header-area-font-weight',
		'header-area-tagline-font-weight',
		'headline-font-weight',
		'headline-subhead-font-weight',
		'nav-menu-font-weight',
		'subnav-menu-font-weight',
		'sidebar-font-weight',
		'sidebar-heading-font-weight',
		'footer-widgets-font-weight',
		'footer-widgets-heading-font-weight',
		'footer-font-weight',
		));
	}
	
	function metaboxes() {
		do_action( 'lander_design_before_metaboxes', $this );
		add_meta_box( 'lander_layout_settings_box', __( 'Layout Settings', CHILD_DOMAIN ), array( $this, 'layout_settings_box' ), $this->pagehook, 'main' );
		
		add_meta_box( 'lander_b_fonts_settings_box', __( 'Body Font', CHILD_DOMAIN ), array( $this, 'b_font_settings_box' ), $this->pagehook, 'main' );
		
		add_meta_box( 'lander_site_heading_settings_box', __( 'Site Header', CHILD_DOMAIN ), array( $this, 'site_header_settings_box' ), $this->pagehook, 'main' );
		
		add_meta_box( 'lander_navmenu_settings_box', __( 'Navigation Menus', CHILD_DOMAIN ), array( $this, 'navmenu_settings_box' ), $this->pagehook, 'main' );
		
		add_meta_box( 'lander_headline_settings_box', __( 'Content Headlines', CHILD_DOMAIN ), array( $this, 'headline_settings_box' ), $this->pagehook, 'main' );
		
		add_meta_box( 'lander_byline_meta_settings_box', __( 'Byline and Post Meta Data', CHILD_DOMAIN ), array( $this, 'byline_meta_settings_box' ), $this->pagehook, 'main' );
		
		add_meta_box( 'lander_precode_settings_box', __( 'Preformatted Code', CHILD_DOMAIN ), array( $this, 'precode_settings_box' ), $this->pagehook, 'main' );
		
		add_meta_box( 'lander_sidebar_settings_box', __( 'Sidebars', CHILD_DOMAIN ), array( $this, 'sidebar_settings_box' ), $this->pagehook, 'main' );
		
		add_meta_box( 'lander_footer_widgets_settings_box', __( 'Footer Widgets', CHILD_DOMAIN ), array( $this, 'footer_widgets_settings_box' ), $this->pagehook, 'main' );
		
		add_meta_box( 'lander_footer_settings_box', __( 'Footer', CHILD_DOMAIN ), array( $this, 'footer_settings_box' ), $this->pagehook, 'main' );
		
		do_action( 'lander_design_after_metaboxes', $this );
	}
	
	function save( $newsettings, $oldsettings ) {	
	
		$newsettings['site-background-color'] = $this->validate_color( $newsettings['site-background-color'], $oldsettings['site-background-color'] );
		$newsettings['page-background-color'] = $this->validate_color( $newsettings['page-background-color'], $oldsettings['page-background-color'] );
		$newsettings['primary-text-color'] = $this->validate_color( $newsettings['primary-text-color'], $oldsettings['primary-text-color'] );
		$newsettings['primary-link-color'] = $this->validate_color( $newsettings['primary-link-color'], $oldsettings['primary-link-color'] );
		$newsettings['primary-link-hover-color'] = $this->validate_color( $newsettings['primary-link-hover-color'], $oldsettings['primary-link-hover-color'] );
		$newsettings['header-area-font-color'] = $this->validate_color( $newsettings['header-area-font-color'], $oldsettings['header-area-font-color'] );
		$newsettings['header-area-tagline-font-color'] = $this->validate_color( $newsettings['header-area-tagline-font-color'], $oldsettings['header-area-tagline-font-color'] );
		$newsettings['headline-font-color'] = $this->validate_color( $newsettings['headline-font-color'], $oldsettings['headline-font-color'] );
		$newsettings['headline-subhead-font-color'] = $this->validate_color( $newsettings['headline-subhead-font-color'], $oldsettings['headline-subhead-font-color'] );
		
		$newsettings['nav-menu-link-text-color'] = $this->validate_color( $newsettings['nav-menu-link-text-color'], $oldsettings['nav-menu-link-text-color'] );
		$newsettings['nav-menu-link-text-hover-color'] = $this->validate_color( $newsettings['nav-menu-link-text-hover-color'], $oldsettings['nav-menu-link-text-hover-color'] );
		$newsettings['nav-menu-current-link-text-color'] = $this->validate_color( $newsettings['nav-menu-current-link-text-color'], $oldsettings['nav-menu-current-link-text-color'] );
		$newsettings['nav-menu-current-parent-link-text-color'] = $this->validate_color( $newsettings['nav-menu-current-parent-link-text-color'], $oldsettings['nav-menu-current-parent-link-text-color'] );
		$newsettings['nav-menu-link-bg-color'] = $this->validate_color( $newsettings['nav-menu-link-bg-color'], $oldsettings['nav-menu-link-bg-color'] );
		$newsettings['nav-menu-hover-bg-color'] = $this->validate_color( $newsettings['nav-menu-hover-bg-color'], $oldsettings['nav-menu-hover-bg-color'] );
		$newsettings['nav-menu-current-bg-color'] = $this->validate_color( $newsettings['nav-menu-current-bg-color'], $oldsettings['nav-menu-current-bg-color'] );
		$newsettings['nav-menu-current-parent-bg-color'] = $this->validate_color( $newsettings['nav-menu-current-parent-bg-color'], $oldsettings['nav-menu-current-parent-bg-color'] );
		$newsettings['nav-menu-border-color'] = $this->validate_color( $newsettings['nav-menu-border-color'], $oldsettings['nav-menu-border-color'] );
		
		$newsettings['subnav-menu-link-text-color'] = $this->validate_color( $newsettings['subnav-menu-link-text-color'], $oldsettings['subnav-menu-link-text-color'] );
		$newsettings['subnav-menu-link-text-hover-color'] = $this->validate_color( $newsettings['subnav-menu-link-text-hover-color'], $oldsettings['subnav-menu-link-text-hover-color'] );
		$newsettings['subnav-menu-current-link-text-color'] = $this->validate_color( $newsettings['subnav-menu-current-link-text-color'], $oldsettings['subnav-menu-current-link-text-color'] );
		$newsettings['subnav-menu-current-parent-link-text-color'] = $this->validate_color( $newsettings['subnav-menu-current-parent-link-text-color'], $oldsettings['subnav-menu-current-parent-link-text-color'] );
		$newsettings['subnav-menu-link-bg-color'] = $this->validate_color( $newsettings['subnav-menu-link-bg-color'], $oldsettings['subnav-menu-link-bg-color'] );
		$newsettings['subnav-menu-hover-bg-color'] = $this->validate_color( $newsettings['subnav-menu-hover-bg-color'], $oldsettings['subnav-menu-hover-bg-color'] );
		$newsettings['subnav-menu-current-bg-color'] = $this->validate_color( $newsettings['subnav-menu-current-bg-color'], $oldsettings['subnav-menu-current-bg-color'] );
		$newsettings['subnav-menu-current-parent-bg-color'] = $this->validate_color( $newsettings['subnav-menu-current-parent-bg-color'], $oldsettings['subnav-menu-current-parent-bg-color'] );
		$newsettings['subnav-menu-border-color'] = $this->validate_color( $newsettings['subnav-menu-border-color'], $oldsettings['subnav-menu-border-color'] );
		
		$newsettings['byline-font-color'] = $this->validate_color( $newsettings['byline-font-color'], $oldsettings['byline-font-color'] );
		$newsettings['code-font-color'] = $this->validate_color( $newsettings['code-font-color'], $oldsettings['code-font-color'] );
		$newsettings['sidebar-font-color'] = $this->validate_color( $newsettings['sidebar-font-color'], $oldsettings['sidebar-font-color'] );
		$newsettings['sidebar-heading-font-color'] = $this->validate_color( $newsettings['sidebar-heading-font-color'], $oldsettings['sidebar-heading-font-color'] );
		$newsettings['footer-font-color'] = $this->validate_color( $newsettings['footer-font-color'], $oldsettings['footer-font-color'] );
		$newsettings['footer-widgets-font-color'] = $this->validate_color( $newsettings['footer-widgets-font-color'], $oldsettings['footer-widgets-font-color'] );
		$newsettings['footer-widgets-heading-font-color'] = $this->validate_color( $newsettings['footer-widgets-heading-font-color'], $oldsettings['footer-widgets-heading-font-color'] );
		$newsettings['content-area-font-size'] = $this->validate_font_sz( $newsettings['content-area-font-size'], $oldsettings['content-area-font-size'] );
		$newsettings['header-area-font-size'] = $this->validate_font_sz( $newsettings['header-area-font-size'], $oldsettings['header-area-font-size'] );
		$newsettings['header-area-tagline-font-size'] = $this->validate_font_sz( $newsettings['header-area-tagline-font-size'], $oldsettings['header-area-tagline-font-size'] );
		$newsettings['headline-font-size'] = $this->validate_font_sz( $newsettings['headline-font-size'], $oldsettings['headline-font-size'] );
		$newsettings['nav-menu-font-size'] = $this->validate_font_sz( $newsettings['nav-menu-font-size'], $oldsettings['nav-menu-font-size'] );
		$newsettings['subnav-menu-font-size'] = $this->validate_font_sz( $newsettings['subnav-menu-font-size'], $oldsettings['subnav-menu-font-size'] );
		$newsettings['sidebar-font-size'] = $this->validate_font_sz( $newsettings['sidebar-font-size'], $oldsettings['sidebar-font-size'] );
		$newsettings['sidebar-heading-font-size'] = $this->validate_font_sz( $newsettings['sidebar-heading-font-size'], $oldsettings['sidebar-heading-font-size'] );
		$newsettings['byline-font-size'] = $this->validate_font_sz( $newsettings['byline-font-size'], $oldsettings['byline-font-size'] );
		$newsettings['code-font-size'] = $this->validate_font_sz( $newsettings['code-font-size'], $oldsettings['code-font-size'] );
		$newsettings['footer-widgets-font-size'] = $this->validate_font_sz( $newsettings['footer-widgets-font-size'], $oldsettings['footer-widgets-font-size'] );
		$newsettings['footer-widgets-heading-font-size'] = $this->validate_font_sz( $newsettings['footer-widgets-heading-font-size'], $oldsettings['footer-widgets-heading-font-size'] );
		$newsettings['footer-font-size'] = $this->validate_font_sz( $newsettings['footer-font-size'], $oldsettings['footer-font-size'] );
		
		return lander_init_css($newsettings);		
	
	}
	
	function validate_color( $clr, $def ) {
		$clrnames = array(
			 'transparent',
			'aliceblue',
			'antiquewhite',
			'aqua',
			'aquamarine',
			'azure',
			'beige',
			'bisque',
			'black',
			'blanchedalmond',
			'blue',
			'blueviolet',
			'brown',
			'burlywood',
			'cadetblue',
			'chartreuse',
			'chocolate',
			'coral',
			'cornflowerblue',
			'cornsilk',
			'crimson',
			'cyan',
			'darkblue',
			'darkcyan',
			'darkgoldenrod',
			'darkgray',
			'darkgreen',
			'darkkhaki',
			'darkmagenta',
			'darkolivegreen',
			'darkorange',
			'darkorchid',
			'darkred',
			'darksalmon',
			'darkseagreen',
			'darkslateblue',
			'darkslategray',
			'darkturquoise',
			'darkviolet',
			'deeppink',
			'deepskyblue',
			'dimgray',
			'dodgerblue',
			'firebrick',
			'floralwhite',
			'forestgreen',
			'fuchsia',
			'gainsboro',
			'ghostwhite',
			'gold',
			'goldenrod',
			'gray',
			'green',
			'greenyellow',
			'honeydew',
			'hotpink',
			'indianred',
			'indigo',
			'ivory',
			'khaki',
			'lavender',
			'lavenderblush',
			'lawngreen',
			'lemonchiffon',
			'lightblue',
			'lightcoral',
			'lightcyan',
			'lightgoldenrodyellow',
			'lightgray',
			'lightgreen',
			'lightpink',
			'lightsalmon',
			'lightseagreen',
			'lightskyblue',
			'lightslategray',
			'lightsteelblue',
			'lightyellow',
			'lime',
			'limegreen',
			'linen',
			'magenta',
			'maroon',
			'mediumaquamarine',
			'mediumblue',
			'mediumorchid',
			'mediumpurple',
			'mediumseagreen',
			'mediumslateblue',
			'mediumspringgreen',
			'mediumturquoise',
			'mediumvioletred',
			'midnightblue',
			'mintcream',
			'mistyrose',
			'moccasin',
			'navajowhite',
			'navy',
			'oldlace',
			'olive',
			'olivedrab',
			'orange',
			'orangered',
			'orchid',
			'palegoldenrod',
			'palegreen',
			'paleturquoise',
			'palevioletred',
			'papayawhip',
			'peachpuff',
			'peru',
			'pink',
			'plum',
			'powderblue',
			'purple',
			'red',
			'rosybrown',
			'royalblue',
			'saddlebrown',
			'salmon',
			'sandybrown',
			'seagreen',
			'seashell',
			'sienna',
			'silver',
			'skyblue',
			'slateblue',
			'slategray',
			'snow',
			'springgreen',
			'steelblue',
			'tan',
			'teal',
			'thistle',
			'tomato',
			'turquoise',
			'violet',
			'wheat',
			'white',
			'whitesmoke',
			'yellow',
			'yellowgreen' 
		);
		if ( preg_match( '/rgba?\((\s+)?\d+(\s+)?,(\s+)?\d+(\s+)?,(\s+)?\d+(\s+)?,\d*(?:\.\d+)?\)/i', $clr ) ) {
			return $clr;
		}
		
		if ( preg_match( '/#([0-9a-f]{3}){1,2}/i', $clr ) ) {
			return $clr;
		}
		else {
			if ( preg_match( '/([0-9a-f]{3}){1,2}/i', $clr ) ) {
				return '#' . $clr;
			}
		}
		
		
		$clr = strtolower( $clr );
		if ( in_array( $clr, $clrnames ) ) {
			return $clr;
		}
		return $def;
	}
	
	function validate_font_sz( $sz, $nsz ) {
		if ( preg_match( '/^[0-9]{1,2}$/', $sz ) ) {
			return $sz;
		}
		return $nsz;
	}
	
	function scripts() {
		parent::scripts();
		genesis_load_admin_js();
		wp_enqueue_script( 'farbtastic' );
		wp_enqueue_script( 'lander-admin-js', CHILD_URL . '/lib/js/lander-admin.js' );
		wp_localize_script( 'lander-admin-js', CHILD_DOMAIN, array(
			'pageHook'      => $this->pagehook,
			'firstTime'     => ! is_array( get_user_option( 'closedpostboxes_' . $this->pagehook ) ),
			) );

	}
	
	function styles() {
		wp_enqueue_style( 'farbtastic' );
		wp_enqueue_style( 'lander-admin-style', CHILD_URL . '/lib/css/lander-admin.css' );
	}
	
	function layout_settings_box() {
		
		$current = genesis_get_option( 'layout', $this->settings_field, false );
		
		?>  
		<div class="gl-section">
		<div class="gl-desc">
		<table class="gl-layout-table">
			<tr>
				<td class="gl-label"  id="label-layout">
				<p><label for="<?php echo $this->settings_field . '[layout]'; ?>"><?php _e( 'Select Layout Style', CHILD_DOMAIN ); ?></label></p>
				</td>
				<td id="layoutwidths" class="lander-input">
				<p>
				<?php
				echo '<input type="radio" id="' . $this->settings_field . '[layout-fullwidth]" name="' . $this->settings_field . '[layout]" value="fullwidth" ' . checked( $current, 'fullwidth', false ) . ' />';
				
				echo '<label id="label-layout-fullwidth" for="' . $this->settings_field . '[layout-fullwidth]">'.__('Full-Width',CHILD_DOMAIN).'</label>';
				
				echo '<br />';
				
				echo '<input type="radio" id="' . $this->settings_field . '[layout-pagewidth]" name="' . $this->settings_field . '[layout]" value="pagewidth" ' . checked( $current, 'pagewidth', false ) . ' />';
				
				echo '<label id="label-layout-pagewidth" for="' . $this->settings_field . '[layout-pagewidth]">'.__('Page-Width', CHILD_DOMAIN).'</label>';
				?>
				</p>
				</td>
			</tr>
			
			<?php
			if ( function_exists( 'bbpress' ) ) {
			?>
				<tr>
					<td colspan="2">
					<p class="l-desc"><strong>These settings only affect the bbPress forum pages.</strong></p>
					</td>
				</tr>
				
				<tr>	
					<td class="gl-label">
					<p><label for="<?php echo $this->settings_field . '[bbpress-layout]'; ?>"><?php _e('Layout For bbPress', CHILD_DOMAIN); ?></label></p>
					</td>
					
					<td class="lander-input">
					<p>
					<?php
					$layouts = genesis_get_layouts();
		
					$current = genesis_get_option( 'bbpress-layout', $this->settings_field, false );
			
					echo '<select id="' . $this->settings_field . '[bbpress-layout]" name="' . $this->settings_field . '[bbpress-layout]">';
			
					echo '<option value="default" ' . selected( $current, 'genesis-default' ) . '>' . __( 'Genesis Default', CHILD_DOMAIN ) . '</option> ';
			
					foreach ( $layouts as $identifier => $keys ) {
						echo '<option value="' . esc_attr( $identifier ) . '" ' . selected( $current, esc_attr( $identifier ) ) . '>' . esc_attr( $keys['label'] ) . '</option>';
					}
			
					echo '</select>';
					?>
					</p>
					</td>
				</tr>
			<?php
			}
			?>
		</table>
		</div>
		
		<div class="gl-desc">
		<table class="gl-col-table">
			<tr>
				<td colspan="3">
				<h4 class="gl-head"><?php _e( 'Genesis Layout Widths', CHILD_DOMAIN ); ?></h4>
				<p class="l-desc"><?php _e( 'You can use these settings to specify the column widths and padding between the columns across all six Genesis layouts.', CHILD_DOMAIN ); ?></p>
				</td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[col-spacing]"><?php _e('Padding Between Columns', CHILD_DOMAIN); ?></label></p>
				</td>
				<td class="lander-input">
				<p><input size="3" class="col-spacing" type="number" id="<?php echo $this->settings_field; ?>[col-spacing]" name="<?php echo $this->settings_field; ?>[col-spacing]" value="<?php echo genesis_get_option( 'col-spacing', $this->settings_field,false ); ?>" />&nbsp;px</p>
				</td>
			</tr>
			
			<tr>
				<td colspan="3">
				<h4 class="gl-head"><?php _e( 'Single Column Layout', CHILD_DOMAIN );?></h4>
				</td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[column-content-1col]"> <?php _e('Content Column Width', CHILD_DOMAIN); ?></label></p>
				</td>
				
				<td class="lander-input"><p>
				<input size="3" class="column-content-1col" type="number" id="<?php echo $this->settings_field; ?>[column-content-1col]" name="<?php echo $this->settings_field; ?>[column-content-1col]" value="<?php echo genesis_get_option( 'column-content-1col', $this->settings_field, false ); ?>" />&nbsp;px</p>
				</td>
				
				<td class="tip" id="tip-one-col">
				<p><?php _e( '<strong>Tip: </strong>Make this a total of <span class="ans"></span> to keep the page-width consistent across different layouts.', CHILD_DOMAIN );?></p>
				</td>
			</tr>
		
			<tr>
				<td colspan="3">
				<h4 class="gl-head"><?php _e( 'Two Column Layout', CHILD_DOMAIN ); ?></h4>
				</td>
			</tr>
			  
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[column-content-2col]"><?php _e('Content Column Width', CHILD_DOMAIN); ?></label></p>
				</td>
			
				<td class="lander-input">
				<p><input size="3" class="column-content-2col" type="number" id="<?php echo $this->settings_field; ?>[column-content-2col]" name="<?php echo $this->settings_field; ?>[column-content-2col]" value="<?php echo genesis_get_option( 'column-content-2col', $this->settings_field, false ); ?>" />&nbsp;px</p>
				</td>
		
				<td rowspan="2"  class="tip" id="tip-two-col"><p><?php _e('<strong>Tip: </strong>Make this a total of <span class="ans"></span> to keep the page-width consistent across different layouts.', CHILD_DOMAIN);?></p></td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[sidebar-one-2col]"><?php _e('Sidebar-One Width', CHILD_DOMAIN); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input size="3" class="sidebar-one-2col" type="number" id="<?php echo $this->settings_field; ?>[sidebar-one-2col]" name="<?php echo $this->settings_field; ?>[sidebar-one-2col]" value="<?php echo genesis_get_option( 'sidebar-one-2col',$this->settings_field,false ); ?>" />&nbsp;px</p>
				</td>
			</tr>
			
			<tr>
				<td colspan="3">
				<h4 class="gl-head"><?php _e('Three Column Layout', CHILD_DOMAIN); ?></h4>
				</td>
			</tr>
			 
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[column-content-3col]"><?php _e('Content Column Width', CHILD_DOMAIN); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input size="3" class="column-content-3col" type="number" id="<?php echo $this->settings_field; ?>[column-content-3col]" name="<?php echo $this->settings_field; ?>[column-content-3col]" value="<?php echo genesis_get_option( 'column-content-3col', $this->settings_field, false ); ?>" />&nbsp;px</p>
				</td>
				
				<td rowspan="3" class="tip" id="tip-three-col">
				<p><?php _e('<strong>Tip: </strong>Make this a total of <span class="ans"></span> to keep the page-width consistent across different layouts.', CHILD_DOMAIN); ?></p>
				</td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[sidebar-one-3col]"><?php _e('Sidebar-One Width',CHILD_DOMAIN); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input size="3" class="sidebar-one-3col" type="number" id="<?php echo $this->settings_field; ?>[sidebar-one-3col]" name="<?php echo $this->settings_field; ?>[sidebar-one-3col]" value="<?php echo genesis_get_option( 'sidebar-one-3col',$this->settings_field,false ); ?>" />&nbsp;px</p>
				</td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[sidebar-two-3col]"><?php _e('Sidebar-Two Width', CHILD_DOMAIN); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input size="3" class="sidebar-two-3col" type="number" id="<?php echo $this->settings_field; ?>[sidebar-two-3col]" name="<?php 		echo $this->settings_field; ?>[sidebar-two-3col]" value="<?php echo genesis_get_option( 'sidebar-two-3col',$this->settings_field,false ); ?>" />&nbsp;px</p>
				</td>
			</tr>
		</table>
		</div>
		
		<div class="gl-desc">
			<table class="gl-col-table">
			<tr>
				<td colspan="2">
				<h4 class="gl-head"><?php _e('Layout Colors',CHILD_DOMAIN);?></h4>
				<p class="l-desc"><?php _e( 'Add some personal flair to your design by using the controls below. You\'ll find even more controls in the other boxes in this section, so you\'ve got lots of ways to let your creativity flow!', CHILD_DOMAIN); ?></p>
				</td>
			</tr>

			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[site-background-color]"><?php _e('Body Background Color', CHILD_DOMAIN);?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input type="text" class="color_validate lander-color-selector" id="<?php echo $this->settings_field; ?>[site-background-color]" name="<?php echo $this->settings_field; ?>[site-background-color]" value="<?php echo genesis_get_option( 'site-background-color', $this->settings_field, false ); ?>" /></p>
				</td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[page-background-color]"><?php _e('Wrap Background Color', CHILD_DOMAIN);?></label></p>
				</td>
				
				<td class="lander-input">
				<p>
				<input type="text" class="color_validate lander-color-selector" id="<?php echo $this->settings_field; ?>[page-background-color]" name="<?php echo $this->settings_field; ?>[page-background-color]" value="<?php echo genesis_get_option( 'page-background-color',$this->settings_field,false ); ?>" /></p>
				</td>
			</tr>
		</table>
		</div>
		</div>
		<?php

	}
		
	function b_font_settings_box() {
		
		?>  
		<div class="gl-section">
		<div class="gl-desc">
		<table class="gl-col-table">
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field . '[body-font-family]'; ?>"><?php _e('Primary Font Family',CHILD_DOMAIN);?></label></p>
				</td>
				
				<td class="lander-input">
				<p>
				<?php
				$current_font = genesis_get_option( 'body-font-family',$this->settings_field,false );
				
				echo '<select id="' . $this->settings_field . '[body-font-family]" name="' . $this->settings_field . '[body-font-family]">';
				
				foreach ( $this->lander_fonts as $font_key => $font ) {
					$selected = selected( $current_font,$font_key, 0 );
					$web_safe = ( $font['web_safe'] ) ? ' *' : '';
					$google   = ( $font['google'] ) ? ' G' : '';
					echo "<option $selected value=\"$font_key\">" . $font['name'] . "$web_safe$google</option>\n";
				}
				
				echo '</select>';
				?>
				</p>
				</td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[content-area-font-size]"><?php _e( 'Primary Font Size', CHILD_DOMAIN );?> </label></p>
				</td>
				
				<td class="lander-input">
				<p><input type="number" min="8" max="72" id="<?php echo $this->settings_field; ?>[content-area-font-size]" name="<?php echo $this->settings_field; ?>[content-area-font-size]" value="<?php echo genesis_get_option( 'content-area-font-size', $this->settings_field, false ); ?>" />&nbsp;px</p>
				</td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[content-area-font-weight]"><?php _e( 'Primary Font Weight', CHILD_DOMAIN );?></label></p>
				</td>
				
				<td class="lander-input">
				<p>
				<?php
				$weights = lander_font_weights();
				$weight = genesis_get_option( 'content-area-font-weight',$this->settings_field,false );				
				?>
				<select id="<?php echo $this->settings_field;?>[content-area-font-weight]" name="<?php echo $this->settings_field; ?>[content-area-font-weight]">
				
				<?php
				foreach ($weights as $value) {
					echo '<option value="'.$value.'" '.selected($value,$weight,false).'>'.$value.'</option>';
				}
				?>
				
				</select>
				</p>
				</td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[primary-text-color]"><?php _e('Text Color', CHILD_DOMAIN);?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input type="text" class="color_validate lander-color-selector" id="<?php echo $this->settings_field; ?>[primary-text-color]" name="<?php echo $this->settings_field; ?>[primary-text-color]" value="<?php echo genesis_get_option( 'primary-text-color', $this->settings_field, false ); ?>" /></p>
				</td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[primary-link-color]"><?php _e('Link Color', CHILD_DOMAIN);?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input type="text" class="color_validate lander-color-selector" id="<?php echo $this->settings_field; ?>[primary-link-color]" name="<?php echo $this->settings_field; ?>[primary-link-color]" value="<?php echo genesis_get_option( 'primary-link-color', $this->settings_field, false ); ?>" /></p>
				</td>
			</tr>

			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[primary-link-hover-color]"><?php _e( 'Link Hover Color', CHILD_DOMAIN ); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input type="text" class="color_validate lander-color-selector" id="<?php echo $this->settings_field; ?>[primary-link-hover-color]" name="<?php echo $this->settings_field; ?>[primary-link-hover-color]" value="<?php echo genesis_get_option( 'primary-link-hover-color', $this->settings_field, false ); ?>" /></p>
				</td>
			</tr>
		</table>
		</div>
		</div>
		<?php
	}
	
	function site_header_settings_box() {

		?>  
		<div class="gl-section">
		<div class="gl-desc">
		<table class="gl-col-table">
			<tr>
				<td colspan="2">
				<h4 class="gl-head"><?php _e( 'Customize The Look Of Site-Title.', CHILD_DOMAIN );?></h4>
				</td>
			</tr>
			
			<tr>	
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field . '[header-area-font-family]'; ?>"><?php _e('Font Family', CHILD_DOMAIN); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p>
				<?php
				echo '<select id="' . $this->settings_field . '[header-area-font-family]" name="' . $this->settings_field . '[header-area-font-family]">';
				
				$haf = genesis_get_option( 'header-area-font-family', $this->settings_field, false );
				foreach ( $this->lander_fonts as $font_key => $font ) {
					$selected = selected($haf,$font_key,0);
					$web_safe = ( $font['web_safe'] ) ? ' *' : '';
					$google   = ( $font['google'] ) ? ' G' : '';
					echo "<option $selected value=\"$font_key\">" . $font['name'] . "$web_safe$google</option>\n";
				}
				
				echo '</select>';
				?>
				</p>
				</td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[header-area-font-size]"><?php _e('Font Size', CHILD_DOMAIN);?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input type="number" min="8" max="72" id="<?php echo $this->settings_field; ?>[header-area-font-size]" name="<?php echo $this->settings_field; ?>[header-area-font-size]" value="<?php echo genesis_get_option( 'header-area-font-size', $this->settings_field, false ); ?>" />&nbsp;px</p>
				</td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[header-area-font-weight]"><?php _e('Font Weight', CHILD_DOMAIN);?></label></p>
				</td>
				
				<td class="lander-input">
				<p>
				<?php
				$weights = lander_font_weights();
				$weight = genesis_get_option( 'header-area-font-weight' ,$this->settings_field,false );
				?>
				<select id="<?php echo $this->settings_field;?>[header-area-font-weight]" name="<?php echo $this->settings_field; ?>[header-area-font-weight]">
				
				<?php
				foreach ($weights as $value) {
					echo '<option value="'.$value.'" '.selected($value,$weight,false).'>'.$value.'</option>';
				}
				?>
				
				</select>
				</p>
				</td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[header-area-font-color]"><?php _e( 'Text Color', CHILD_DOMAIN ); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input type="text" class="color_validate lander-color-selector" id="<?php echo $this->settings_field; ?>[header-area-font-color]" name="<?php echo $this->settings_field; ?>[header-area-font-color]" value="<?php echo genesis_get_option( 'header-area-font-color', $this->settings_field, false ); ?>" /></p>
				</td>
			</tr>
		</table>
		</div>
		
		<div class="gl-desc">
		<table class="gl-col-table">
			<tr>
				<td colspan="2">
				<h4 class="gl-head"><?php _e('Customize The Look Of Site-Tagline.', CHILD_DOMAIN);?></h4>
				</td>
			</tr>
			
			<tr>	
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field . '[header-area-tagline-font-family]'; ?>"><?php _e( 'Font Family', CHILD_DOMAIN ); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p>
				<?php
				echo '<select id="' . $this->settings_field . '[header-area-tagline-font-family]" name="' . $this->settings_field . '[header-area-tagline-font-family]">';
				
				$htf = genesis_get_option( 'header-area-tagline-font-family' ,$this->settings_field,false );
				
				foreach ( $this->lander_fonts as $font_key => $font ) {
					$selected = selected( $htf , $font_key,0 );
					$web_safe = ( $font['web_safe'] ) ? ' *' : '';
					$google   = ( $font['google'] ) ? ' G' : '';
					echo "<option $selected value=\"$font_key\">" . $font['name'] . "$web_safe$google</option>\n";
				}
		
				echo '</select>';
				?>
				</p>
				</td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[header-area-tagline-font-size]"><?php _e( 'Font Size', CHILD_DOMAIN ); ?></label></p>
				</td>
			
				<td class="lander-input">
				<p><input type="number" min="8" max="72" id="<?php echo $this->settings_field; ?>[header-area-tagline-font-size]" name="<?php echo $this->settings_field; ?>[header-area-tagline-font-size]" value="<?php echo genesis_get_option( 'header-area-tagline-font-size', $this->settings_field, false ); ?>" />&nbsp;px</p>
				</td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[header-area-tagline-font-weight]"><?php _e( 'Font Weight', CHILD_DOMAIN ); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p>
				<?php
				$weights = lander_font_weights();
				$weight = genesis_get_option( 'header-area-tagline-font-weight', $this->settings_field, false );
				?>
				<select id="<?php echo $this->settings_field;?>[header-area-tagline-font-weight]" name="<?php echo $this->settings_field; ?>[header-area-tagline-font-weight]">
				
				<?php
				foreach ($weights as $value) {
					echo '<option value="'.$value.'" '.selected($value,$weight,false).'>'.$value.'</option>';
				}
				?>
				
				</select>
				</p>
				</td>
			</tr>			  
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[header-area-tagline-font-color]"><?php _e( 'Text Color', CHILD_DOMAIN ); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input type="text" class="color_validate lander-color-selector" id="<?php echo $this->settings_field; ?>[header-area-tagline-font-color]" name="<?php echo $this->settings_field; ?>[header-area-tagline-font-color]" value="<?php echo genesis_get_option( 'header-area-tagline-font-color', $this->settings_field, false ); ?>" /></p>
				</td>
			</tr>
		</table>
		</div>
		</div>
		<?php
		
	}	
	
	function headline_settings_box() {
	
	?>
		<div class="gl-section">
		<div class="gl-desc">
		<table class="gl-col-table">
			<tr>
				<td colspan="2">
				<h4 class="gl-head"><?php _e( 'Post / Page Titles', CHILD_DOMAIN ); ?></h4></td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field . '[headline-font-family]'; ?>"><?php _e('Font Family', CHILD_DOMAIN);?></label></p>
				</td>
				
				<td class="lander-input">
				<p>
				<?php
				echo '<select id="' . $this->settings_field . '[headline-font-family]" name="' . $this->settings_field . '[headline-font-family]">';
				
				$hl = genesis_get_option( 'headline-font-family',$this->settings_field,false );
		
				foreach ( $this->lander_fonts as $font_key => $font ) {
					$selected = selected( $hl, $font_key, 0 );
					$web_safe = ( $font['web_safe'] ) ? ' *' : '';
					$google   = ( $font['google'] ) ? ' G' : '';
					echo "<option $selected value=\"$font_key\">" . $font['name'] . "$web_safe$google</option>\n";
				}
		
				echo '</select>';
				?>
				</p>
				</td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[headline-font-size]"><?php _e( 'Font Size', CHILD_DOMAIN ); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input type="number" min="8" max="72" id="<?php echo $this->settings_field; ?>[headline-font-size]" name="<?php echo $this->settings_field; ?>[headline-font-size]" value="<?php echo genesis_get_option( 'headline-font-size', $this->settings_field, false ); ?>" />&nbsp;px</p>
				</td>
			</tr>
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[headline-font-weight]"><?php _e( 'Font Weight', CHILD_DOMAIN ); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p>
				<?php
				$weights = lander_font_weights();
				$weight = genesis_get_option( 'headline-font-weight', $this->settings_field, false );
				?>
				<select id="<?php echo $this->settings_field; ?>[headline-font-weight]" name="<?php echo $this->settings_field; ?>[headline-font-weight]">
				
				<?php
				foreach ($weights as $value) {
					echo '<option value="'.$value.'" '.selected($value,$weight,false).'>'.$value.'</option>';
				}
				?>
				
				</select>
				</p>
				</td>
			</tr>			  
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[headline-font-color]"><?php _e( 'Text Color', CHILD_DOMAIN ); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input type="text" class="color_validate lander-color-selector" id="<?php echo $this->settings_field; ?>[headline-font-color]" name="<?php echo $this->settings_field; ?>[headline-font-color]" value="<?php echo genesis_get_option( 'headline-font-color', $this->settings_field, false ); ?>" /></p>
				</td>
			</tr>
			
			<tr>
				<td colspan="2">
				<h4 class="gl-head"><?php _e( 'Headlines Inside The Post / Page Body',  CHILD_DOMAIN ); ?></h4>
				</td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field . '[headline-subhead-font-family]'; ?>"><?php _e( 'Font Family', CHILD_DOMAIN ); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p>
				<?php
				echo '<select id="' . $this->settings_field . '[headline-subhead-font-family]" name="' . $this->settings_field . '[headline-subhead-font-family]">';
				$subhl = genesis_get_option( 'headline-subhead-font-family' ,$this->settings_field,false );
				
				foreach ( $this->lander_fonts as $font_key => $font ) {
					$selected = selected( $subhl , $font_key ,0);
					$web_safe = ( $font['web_safe'] ) ? ' *' : '';
					$google   = ( $font['google'] ) ? ' G' : '';
					echo "<option $selected value=\"$font_key\">" . $font['name'] . "$web_safe$google</option>\n";
				}
				
				echo '</select>';
				?>
				</p>
				</td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[headline-subhead-font-weight]"><?php _e( 'Font Weight', CHILD_DOMAIN ); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p>
				<?php
				$weights = lander_font_weights();
				$weight = genesis_get_option( 'headline-subhead-font-weight',$this->settings_field,false );
				?>
				<select id="<?php echo $this->settings_field;?>[headline-subhead-font-weight]" name="<?php echo $this->settings_field; ?>[headline-subhead-font-weight]">
				
				<?php
				foreach ($weights as $value) {
					echo '<option value="'.$value.'" '.selected($value,$weight,false).'>'.$value.'</option>';
				}
				?>
				
				</select>
				</p>
				</td>
			</tr>			  
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[headline-subhead-font-color]"><?php _e( 'Text Color', CHILD_DOMAIN ); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input type="text" class="color_validate lander-color-selector" id=" <?php echo $this->settings_field; ?>[headline-subhead-font-color]" name=" <?php echo $this->settings_field; ?>[headline-subhead-font-color]" value="<?php echo genesis_get_option( 'headline-subhead-font-color', $this->settings_field, false ); ?>" /></p>
				</td>
			</tr>
		</table>
		</div>
		</div>
		<?php
		
	}
	
	function navmenu_settings_box() {
?>
		<div class="gl-section">
		  <div class="gl-desc">
			<table class="gl-col-table">
				<tr>
					<td colspan="2">
					<p class="l-desc"><?php _e( 'These settings allow you to have a finer control over the styles of the menu-items for primary and secondary navigation.', CHILD_DOMAIN );?></p>
				</td>
			</tr>
			
			<tr>
				<td colspan="2"><h4 class="gl-head"><?php _e( 'Primary Navigation (Below Header Menu 1)', CHILD_DOMAIN );?></h4></td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field . '[nav-menu-font-family]'; ?>"><?php _e( 'Font Family', CHILD_DOMAIN );?></label></p>
				</td>
				
				<td class="lander-input">
				<p>
				<?php
				echo '<select id="' . $this->settings_field . '[nav-menu-font-family]" name="' . $this->settings_field . '[nav-menu-font-family]">';
				$navh = genesis_get_option( 'nav-menu-font-family' ,$this->settings_field,false );
				
				foreach ( $this->lander_fonts as $font_key => $font ) {
					$selected = selected( $navh, $font_key,0 );
					$web_safe = ( $font['web_safe'] ) ? ' *' : '';
					$google   = ( $font['google'] ) ? ' G' : '';
					echo "<option $selected value=\"$font_key\">" . $font['name'] . "$web_safe$google</option>\n";
				}
				
				echo '</select>';
				?>
				</p>
				</td>
			</tr>		  
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[nav-menu-font-size]"><?php _e('Font Size',CHILD_DOMAIN);?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input type="number" min="8" max="72" id="<?php echo $this->settings_field; ?>[nav-menu-font-size]" name="<?php echo $this->settings_field; ?>[nav-menu-font-size]" value="<?php echo genesis_get_option( 'nav-menu-font-size' ,$this->settings_field,false ); ?>" />&nbsp;px</p></td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[nav-menu-font-weight]"><?php _e( 'Font Weight', CHILD_DOMAIN ); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p>
				<?php
				$weights = lander_font_weights();
				$weight = genesis_get_option( 'nav-menu-font-weight' ,$this->settings_field,false );
				?>
				<select id="<?php echo $this->settings_field;?>[nav-menu-font-weight]" name="<?php echo $this->settings_field; ?>[nav-menu-font-weight]">
				
				<?php
				foreach ($weights as $value) {
					echo '<option value="'.$value.'" '.selected($value,$weight,false).'>'.$value.'</option>';
				}
				?>
				
				</select>
				</p>
				</td>
			</tr>				  
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[nav-menu-link-text-color]"><?php _e( 'Nav Menu Text Color', CHILD_DOMAIN ); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input type="text" class="color_validate lander-color-selector" id="<?php echo $this->settings_field; ?>[nav-menu-link-text-color]" name="<?php echo $this->settings_field; ?>[nav-menu-link-text-color]" value="<?php echo genesis_get_option( 'nav-menu-link-text-color' ,$this->settings_field, false ); ?>" /></p>
				</td>
			</tr>
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[nav-menu-link-text-hover-color]"><?php _e( 'Nav Menu Hover Text Color', CHILD_DOMAIN );?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input type="text" class="color_validate lander-color-selector" id="<?php echo $this->settings_field; ?>[nav-menu-link-text-hover-color]" name="<?php echo $this->settings_field; ?>[nav-menu-link-text-hover-color]" value="<?php echo genesis_get_option( 'nav-menu-link-text-hover-color', $this->settings_field, false ); ?>" /></p>
				</td>
			</tr>
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[nav-menu-current-link-text-color]"><?php _e( 'Current Link Text Color', CHILD_DOMAIN); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input type="text" class="color_validate lander-color-selector" id="<?php echo $this->settings_field; ?>[nav-menu-current-link-text-color]" name="<?php echo $this->settings_field; ?>[nav-menu-current-link-text-color]" value="<?php echo genesis_get_option( 'nav-menu-current-link-text-color', $this->settings_field, false ); ?>" /></p>
				</td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[nav-menu-current-parent-link-text-color]"><?php _e( 'Parent Nav Link Text Color', CHILD_DOMAIN ); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input type="text" class="color_validate lander-color-selector" id="<?php echo $this->settings_field; ?>[nav-menu-current-parent-link-text-color]" name="<?php echo $this->settings_field; ?>[nav-menu-current-parent-link-text-color]" value="<?php echo genesis_get_option( 'nav-menu-current-parent-link-text-color', $this->settings_field, false ); ?>" /></p>
				</td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[nav-menu-link-bg-color]"><?php _e( 'Nav Menu Link Background Color', CHILD_DOMAIN ); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input type="text" class="color_validate lander-color-selector" id="<?php echo $this->settings_field; ?>[nav-menu-link-bg-color]" name="<?php echo $this->settings_field; ?>[nav-menu-link-bg-color]" value="<?php echo genesis_get_option( 'nav-menu-link-bg-color', $this->settings_field, false ); ?>" /></p>
				</td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[nav-menu-hover-bg-color]"><?php _e( 'Nav Menu Link Hover Background Color', CHILD_DOMAIN ); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input type="text" class="color_validate lander-color-selector" id="<?php echo $this->settings_field; ?>[nav-menu-hover-bg-color]" name="<?php echo $this->settings_field; ?>[nav-menu-hover-bg-color]" value="<?php echo genesis_get_option( 'nav-menu-hover-bg-color', $this->settings_field, false ); ?>" /></p>
				</td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[nav-menu-current-bg-color]"><?php _e( 'Current Link Background Color', CHILD_DOMAIN ); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input type="text" class="color_validate lander-color-selector" id="<?php echo $this->settings_field; ?>[nav-menu-current-bg-color]" name="<?php echo $this->settings_field; ?>[nav-menu-current-bg-color]" value="<?php echo genesis_get_option( 'nav-menu-current-bg-color', $this->settings_field, false ); ?>" /></p>
				</td>
			</tr>
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[nav-menu-current-parent-bg-color]"><?php _e( 'Parent Nav Link Background Color', CHILD_DOMAIN ); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input type="text" class="color_validate lander-color-selector" id="<?php echo $this->settings_field; ?>[nav-menu-current-parent-bg-color]" name="<?php echo $this->settings_field; ?>[nav-menu-current-parent-bg-color]" value="<?php echo genesis_get_option( 'nav-menu-current-parent-bg-color', $this->settings_field, false ); ?>" /></p>
				</td>
			</tr>
			<tr>
				<td class="gl-label">
				<p><label for="<?php echo $this->settings_field; ?>[nav-menu-border-width]"><?php _e( 'Nav Menu Border Width', CHILD_DOMAIN ); ?></label></p>
				</td>
				
				<td class="lander-input">
				<p><input maxlength="1" type="number" id="<?php echo $this->settings_field; ?>[nav-menu-border-width]" name="<?php echo $this->settings_field; ?>[nav-menu-border-width]" value="<?php echo genesis_get_option( 'nav-menu-border-width', $this->settings_field, false ); ?>" /></p>
				</td>
			</tr>
			<tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[nav-menu-border-color]"><?php _e('Nav Menu Border Color', CHILD_DOMAIN);?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input type="text" class="color_validate lander-color-selector" id="<?php
		echo $this->settings_field;
?>[nav-menu-border-color]" name="<?php
		echo $this->settings_field;
?>[nav-menu-border-color]" value="<?php
		echo genesis_get_option( 'nav-menu-border-color' ,$this->settings_field,false );
?>" />
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[nav-menu-submenu-width]"><?php _e('Submenu Width', CHILD_DOMAIN); ?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input maxlength="3" type="number" id="<?php
		echo $this->settings_field;
?>[nav-menu-submenu-width]" name="<?php
		echo $this->settings_field;
?>[nav-menu-submenu-width]" value="<?php
		echo genesis_get_option( 'nav-menu-submenu-width' ,$this->settings_field,false );
?>" />&nbsp;px
				  </p></td>
			  </tr>
			  <tr><td colspan="2"><h4 class="gl-head"><?php _e( 'Secondary Navigation (Top Right Menu)', CHILD_DOMAIN ); ?></h4></td></tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field . '[subnav-menu-font-family]';
?>">Font Family</label>
				  </p></td>
				<td class="lander-input"><p>
					<?php
		echo '<select id="' . $this->settings_field . '[subnav-menu-font-family]" name="' . $this->settings_field . '[subnav-menu-font-family]">';
		$subnavh = genesis_get_option( 'subnav-menu-font-family' ,$this->settings_field,false );
		foreach ( $this->lander_fonts as $font_key => $font ) {
			$selected = selected( $subnavh, $font_key, 0 );
			$web_safe = ( $font['web_safe'] ) ? ' *' : '';
			$google   = ( $font['google'] ) ? ' G' : '';
			echo "<option $selected value=\"$font_key\">" . $font['name'] . "$web_safe$google</option>\n";
		}
		echo '</select>';
?>
				  </p></td>
			  </tr>		  
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[subnav-menu-font-size]"><?php _e('Font Size', CHILD_DOMAIN); ?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input type="number" min="8" max="72" id="<?php
		echo $this->settings_field;
?>[subnav-menu-font-size]" name="<?php
		echo $this->settings_field;
?>[subnav-menu-font-size]" value="<?php
		echo genesis_get_option( 'subnav-menu-font-size' ,$this->settings_field,false );
?>" />&nbsp;px
				  </p></td>
			</tr>
			<tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[subnav-menu-font-weight]"><?php _e('Font Weight', CHILD_DOMAIN); ?></label>
				  </p></td>
				<td class="lander-input"><p>
				<?php
				$weights = lander_font_weights();
				$weight = genesis_get_option( 'subnav-menu-font-weight' ,$this->settings_field,false );
				?>
					<select id="<?php echo $this->settings_field;?>[subnav-menu-font-weight]" name="<?php echo $this->settings_field; ?>[subnav-menu-font-weight]">
					<?php
					foreach ($weights as $value) {
						echo '<option value="'.$value.'" '.selected($value,$weight,false).'>'.$value.'</option>';
					}
					?>
					</select>
				  </p></td>
			  </tr>				  
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[subnav-menu-link-text-color]"><?php _e('Menu Text Color', CHILD_DOMAIN); ?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input type="text" class="color_validate lander-color-selector" id="<?php
		echo $this->settings_field;
?>[subnav-menu-link-text-color]" name="<?php
		echo $this->settings_field;
?>[subnav-menu-link-text-color]" value="<?php
		echo genesis_get_option( 'subnav-menu-link-text-color' ,$this->settings_field,false );
?>" />
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[subnav-menu-link-text-hover-color]"><?php _e('Menu Hover Text Color', CHILD_DOMAIN); ?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input type="text" class="color_validate lander-color-selector" id="<?php
		echo $this->settings_field;
?>[subnav-menu-link-text-hover-color]" name="<?php
		echo $this->settings_field;
?>[subnav-menu-link-text-hover-color]" value="<?php
		echo genesis_get_option( 'subnav-menu-link-text-hover-color' ,$this->settings_field,false );
?>" />
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[subnav-menu-current-link-text-color]"><?php _e('Current Link Text Color', CHILD_DOMAIN); ?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input type="text" class="color_validate lander-color-selector" id="<?php
		echo $this->settings_field;
?>[subnav-menu-current-link-text-color]" name="<?php
		echo $this->settings_field;
?>[subnav-menu-current-link-text-color]" value="<?php
		echo genesis_get_option( 'subnav-menu-current-link-text-color' ,$this->settings_field,false );
?>" />
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[subnav-menu-current-parent-link-text-color]"><?php _e('Parent Nav Link Text Color', CHILD_DOMAIN); ?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input type="text" class="color_validate lander-color-selector" id="<?php
		echo $this->settings_field;
?>[subnav-menu-current-parent-link-text-color]" name="<?php
		echo $this->settings_field;
?>[subnav-menu-current-parent-link-text-color]" value="<?php
		echo genesis_get_option( 'subnav-menu-current-parent-link-text-color' ,$this->settings_field,false );
?>" />
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[subnav-menu-link-bg-color]"><?php _e('Menu Link Background Color', CHILD_DOMAIN); ?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input type="text" class="color_validate lander-color-selector" id="<?php
		echo $this->settings_field;
?>[subnav-menu-link-bg-color]" name="<?php
		echo $this->settings_field;
?>[subnav-menu-link-bg-color]" value="<?php
		echo genesis_get_option( 'subnav-menu-link-bg-color' ,$this->settings_field,false );
?>" />
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[subnav-menu-hover-bg-color]"><?php _e('Menu Link Hover Background Color', CHILD_DOMAIN); ?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input type="text" class="color_validate lander-color-selector" id="<?php
		echo $this->settings_field;
?>[subnav-menu-hover-bg-color]" name="<?php
		echo $this->settings_field;
?>[subnav-menu-hover-bg-color]" value="<?php
		echo genesis_get_option( 'subnav-menu-hover-bg-color' ,$this->settings_field,false );
?>" />
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[subnav-menu-current-bg-color]"><?php _e('Current Link Background Color', CHILD_DOMAIN); ?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input type="text" class="color_validate lander-color-selector" id="<?php
		echo $this->settings_field;
?>[subnav-menu-current-bg-color]" name="<?php
		echo $this->settings_field;
?>[subnav-menu-current-bg-color]" value="<?php
		echo genesis_get_option( 'subnav-menu-current-bg-color' ,$this->settings_field,false );
?>" />
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[subnav-menu-current-parent-bg-color]"><?php _e('Parent Nav Link Background Color', CHILD_DOMAIN); ?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input type="text" class="color_validate lander-color-selector" id="<?php
		echo $this->settings_field;
?>[subnav-menu-current-parent-bg-color]" name="<?php
		echo $this->settings_field;
?>[subnav-menu-current-parent-bg-color]" value="<?php
		echo genesis_get_option( 'subnav-menu-current-parent-bg-color' ,$this->settings_field,false );
?>" />
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[subnav-menu-border-width]"><?php _e('Nav Menu Border Width', CHILD_DOMAIN); ?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input maxlength="1" type="number" id="<?php
		echo $this->settings_field;
?>[subnav-menu-border-width]" name="<?php
		echo $this->settings_field;
?>[subnav-menu-border-width]" value="<?php
		echo genesis_get_option( 'subnav-menu-border-width' ,$this->settings_field,false );
?>" />
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[subnav-menu-border-color]"><?php _e('Nav Menu Border Color', CHILD_DOMAIN); ?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input type="text" class="color_validate lander-color-selector" id="<?php
		echo $this->settings_field;
?>[subnav-menu-border-color]" name="<?php
		echo $this->settings_field;
?>[subnav-menu-border-color]" value="<?php
		echo genesis_get_option( 'subnav-menu-border-color' ,$this->settings_field,false );
?>" />
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[subnav-menu-submenu-width]"><?php _e('Submenu Width', CHILD_DOMAIN); ?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input maxlength="3" type="number" id="<?php
		echo $this->settings_field;
?>[subnav-menu-submenu-width]" name="<?php
		echo $this->settings_field;
?>[subnav-menu-submenu-width]" value="<?php
		echo genesis_get_option( 'subnav-menu-submenu-width' ,$this->settings_field,false );
?>" />&nbsp;px
				  </p></td>
			  </tr>
			</table>
		  </div>
		</div>
		<?php
	}
	
	function byline_meta_settings_box() {
?>
		<div class="gl-section">
		  <div class="gl-desc">
			<table class="gl-col-table">
			  <tr>
				<td colspan="2"><p class="l-desc"><?php _e('These settings affect the post bylines (entry-meta) of the posts & pages.',CHILD_DOMAIN);?></p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field . '[byline-font-family]';
?>"><?php _e('Font Family',CHILD_DOMAIN);?></label>
				  </p></td>
				<td class="lander-input"><p>
					<?php
		echo '<select id="' . $this->settings_field . '[byline-font-family]" name="' . $this->settings_field . '[byline-font-family]">';
		$byh = genesis_get_option( 'byline-font-family' ,$this->settings_field,false );
		foreach ( $this->lander_fonts as $font_key => $font ) {
			$selected = selected( $byh, $font_key, 0 );
			$web_safe = ( $font['web_safe'] ) ? ' *' : '';
			$google   = ( $font['google'] ) ? ' G' : '';
			echo "<option $selected value=\"$font_key\">" . $font['name'] . "$web_safe$google</option>\n";
		}
		echo '</select>';
?>
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[byline-font-size]"><?php _e('Font Size',CHILD_DOMAIN);?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input type="number" min="8" max="72" id="<?php
		echo $this->settings_field;
?>[byline-font-size]" name="<?php
		echo $this->settings_field;
?>[byline-font-size]" value="<?php
		echo genesis_get_option( 'byline-font-size' ,$this->settings_field,false );
?>" />&nbsp;px
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[byline-font-color]"><?php _e('Text Color',CHILD_DOMAIN);?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input type="text" class="color_validate lander-color-selector" id="<?php
		echo $this->settings_field;
?>[byline-font-color]" name="<?php
		echo $this->settings_field;
?>[byline-font-color]" value="<?php
		echo genesis_get_option( 'byline-font-color' ,$this->settings_field,false );
?>" />
				  </p></td>
			  </tr>
			</table>
		  </div>
		</div>
		<?php
	}
	
	function precode_settings_box() {
?>
		<div class="gl-section">
		  <div class="gl-desc">
			<table class="gl-col-table">
			  <tr>
				<td colspan="2"><p class="l-desc"><?php _e('These settings affect both <code>&lt;code&gt;</code> and <code>&lt;pre&gt;</code> tags within your posts. The size only affects the preformatted code (<code>&lt;pre&gt;</code>).', CHILD_DOMAIN);?></p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[code-font-family]"><?php _e('Font Family', CHILD_DOMAIN);?></label>
				  </p></td>
				<td class="lander-input"><p>
					<select id="<?php
		$code_font_family = genesis_get_option( 'code-font-family' ,$this->settings_field,false );
		echo $this->settings_field;
?>[code-font-family]" name="<?php
		echo $this->settings_field;
?>[code-font-family]">
					  <option value='consolas' <?php
		if ( $code_font_family == 'consolas' )
			echo 'selected="selected"';
?>>Consolas</option>
					  <option value='courier_new' <?php
		if ( $code_font_family == 'courier_new' )
			echo 'selected="selected"';
?>>Courier New *</option>
					  <option value='andale' <?php
		if ( $code_font_family == 'andale' )
			echo 'selected="selected"';
?>>Andale Mono</option>
					  <option value='0' <?php
		if ( $code_font_family == '0' )
			echo 'selected="selected"';
?>>Inherited from Body</option>
					</select>
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[code-font-size]"><?php _e('Font Size', CHILD_DOMAIN);?><br /><small><em>* <?php _e('Only for &lt;pre&gt; tag.', CHILD_DOMAIN);?></em></small></label>
				  </p></td>
				<td class="lander-input"><p>
					<input id="<?php
		echo $this->settings_field;
?>[code-font-size]" type="number" min="8" max="72" name="<?php
		echo $this->settings_field;
?>[code-font-size]" value="<?php
		echo genesis_get_option( 'code-font-size' ,$this->settings_field,false );
?>" />&nbsp;px
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[code-font-color]"><?php _e('Text Color', CHILD_DOMAIN);?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input id="<?php
		echo $this->settings_field;
?>[code-font-color]" type="text" class="color_validate lander-color-selector" name="<?php
		echo $this->settings_field;
?>[code-font-color]" value="<?php
		echo genesis_get_option( 'code-font-color' ,$this->settings_field,false );
?>" />
				  </p></td>
			  </tr>
			</table>
		  </div>
		</div>
		<?php
	}
	
	function sidebar_settings_box() {
?>
		<div class="gl-section">
		  <div class="gl-desc">
			<table class="gl-col-table">
			<tr>
				<td colspan="2"><h4 class="gl-head"><?php _e('Sidebar Widget Headings', CHILD_DOMAIN); ?></h4></td>
			</tr>
			<tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field . '[sidebar-heading-font-family]';
?>"><?php _e('Font Family', CHILD_DOMAIN); ?></label>
				  </p></td>
				<td class="lander-input"><p>
					<?php
		echo '<select id = "' . $this->settings_field . '[sidebar-heading-font-family]" name="' . $this->settings_field . '[sidebar-heading-font-family]" >';
		$ssh = genesis_get_option( 'sidebar-heading-font-family' ,$this->settings_field,false );
		foreach ( $this->lander_fonts as $font_key => $font ) {
			$selected = selected( $ssh , $font_key ,0);
			$web_safe = ( $font['web_safe'] ) ? ' *' : '';
			$google   = ( $font['google'] ) ? ' G' : '';
			echo "<option $selected value=\"$font_key\">" . $font['name'] . "$web_safe$google</option>\n";
		}
		echo '</select>';
?>
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[sidebar-heading-font-size]"><?php _e('Font Size', CHILD_DOMAIN); ?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input type="number" min="8" max="72" id="<?php
		echo $this->settings_field;
?>[sidebar-heading-font-size]" name="<?php
		echo $this->settings_field;
?>[sidebar-heading-font-size]" value="<?php
		echo genesis_get_option( 'sidebar-heading-font-size' ,$this->settings_field,false );
?>" />&nbsp;px
				  </p></td>
			  </tr>
			<tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[sidebar-heading-font-weight]"><?php _e('Font Weight', CHILD_DOMAIN); ?></label>
				  </p></td>
				<td class="lander-input"><p>
				<?php
				$weights = lander_font_weights();
				$weight = genesis_get_option( 'sidebar-heading-font-weight' ,$this->settings_field,false );
				?>
					<select id="<?php echo $this->settings_field;?>[sidebar-heading-font-weight]" name="<?php echo $this->settings_field; ?>[sidebar-heading-font-weight]">
					<?php
					foreach ($weights as $value) {
						echo '<option value="'.$value.'" '.selected($value,$weight,false).'>'.$value.'</option>';
					}
					?>
					</select>
				  </p></td>
			  </tr>			  
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[sidebar-heading-font-color]"><?php _e('Text Color', CHILD_DOMAIN); ?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input type="text" class="color_validate lander-color-selector" id="<?php
		echo $this->settings_field;
?>[sidebar-heading-font-color]" name="<?php
		echo $this->settings_field;
?>[sidebar-heading-font-color]" value="<?php
		echo genesis_get_option( 'sidebar-heading-font-color' ,$this->settings_field,false );
?>" />
				  </p></td>
			  </tr>
			  <tr>
				<td colspan="2"><h4 class="gl-head"><?php _e('Sidebar Widget Body', CHILD_DOMAIN); ?></h4></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field . '[sidebar-font-family]';
?>"><?php _e('Font Family', CHILD_DOMAIN); ?></label>
				  </p></td>
				<td class="lander-input"><p>
					<?php
		echo '<select id="' . $this->settings_field . '[sidebar-font-family]" name="' . $this->settings_field . '[sidebar-font-family]">';
		$sf = genesis_get_option( 'sidebar-font-family' ,$this->settings_field,false );
		foreach ( $this->lander_fonts as $font_key => $font ) {
			$selected = selected( $sf , $font_key ,0 );
			$web_safe = ( $font['web_safe'] ) ? ' *' : '';
			$google   = ( $font['google'] ) ? ' G' : '';
			echo "<option $selected value=\"$font_key\">" . $font['name'] . "$web_safe$google</option>\n";
		} 
		echo '</select>';
?>
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[sidebar-font-size]"><?php _e('Font Size', CHILD_DOMAIN); ?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input type="number" min="8" max="72" id="<?php
		echo $this->settings_field;
?>[sidebar-font-size]" name="<?php
		echo $this->settings_field;
?>[sidebar-font-size]" value="<?php
		echo genesis_get_option( 'sidebar-font-size' ,$this->settings_field,false );
?>" />&nbsp;px
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[sidebar-font-weight]"><?php _e('Font Weight', CHILD_DOMAIN); ?></label>
				  </p></td>
				<td class="lander-input"><p>
				<?php
				$weights = lander_font_weights();
				$weight = genesis_get_option( 'sidebar-font-weight' ,$this->settings_field,false );
				?>
					<select id="<?php echo $this->settings_field;?>[sidebar-font-weight]" name="<?php echo $this->settings_field; ?>[sidebar-font-weight]">
					<?php
					foreach ($weights as $value) {
						echo '<option value="'.$value.'" '.selected($value,$weight,false).'>'.$value.'</option>';
					}
					?>
					</select>
				  </p></td>
			  </tr>			  
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[sidebar-font-color]"><?php _e('Text Color', CHILD_DOMAIN); ?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input type="text" class="color_validate lander-color-selector" id="<?php
		echo $this->settings_field;
?>[sidebar-font-color]" name="<?php
		echo $this->settings_field;
?>[sidebar-font-color]" value="<?php
		echo genesis_get_option( 'sidebar-font-color' ,$this->settings_field,false );
?>" />
				  </p></td>
			  </tr>
			</table>
		  </div>
		</div>
		<?php
	}
	
	function footer_widgets_settings_box() {
?>	
		<div class="gl-section">
		  <div class="gl-desc">
			<table class="gl-col-table">
			  <tr>
				<td colspan="2"><h4 class="gl-head"><?php _e('Footer Widget Headings', CHILD_DOMAIN);?></h4></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field . '[footer-widgets-heading-font-family]';
?>"><?php _e('Font Family', CHILD_DOMAIN);?></label>
				  </p></td>
				<td class="lander-input"><p>
					<?php
		echo '<select id="' . $this->settings_field . '[footer-widgets-heading-font-family]" name="' . $this->settings_field . '[footer-widgets-heading-font-family]">';
		$fwh = genesis_get_option( 'footer-widgets-heading-font-family' ,$this->settings_field,false );
		foreach ( $this->lander_fonts as $font_key => $font ) {
			$selected = selected( $fwh, $font_key,0 );
			$web_safe = ( $font['web_safe'] ) ? ' *' : '';
			$google   = ( $font['google'] ) ? ' G' : '';
			echo "<option $selected value=\"$font_key\">" . $font['name'] . "$web_safe$google</option>\n";
		}
		echo '</select>';
?>
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[footer-widgets-heading-font-size]"><?php _e('Font Size', CHILD_DOMAIN);?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input type="number" id="<?php
		echo $this->settings_field;
?>[footer-widgets-heading-font-size]" name="<?php
		echo $this->settings_field;
?>[footer-widgets-heading-font-size]" value="<?php
		echo genesis_get_option( 'footer-widgets-heading-font-size' ,$this->settings_field,false );
?>" />&nbsp;px
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[footer-widgets-heading-font-weight]"><?php _e('Primary Font Weight', CHILD_DOMAIN);?></label>
				  </p></td>
				<td class="lander-input"><p>
				<?php
				$weights = lander_font_weights();
				$weight = genesis_get_option( 'footer-widgets-heading-font-weight' ,$this->settings_field,false );
				?>
					<select id="<?php echo $this->settings_field;?>[footer-widgets-heading-font-weight]" name="<?php echo $this->settings_field; ?>[footer-widgets-heading-font-weight]">
					<?php
					foreach ($weights as $value) {
						echo '<option value="'.$value.'" '.selected($value,$weight,false).'>'.$value.'</option>';
					}
					?>
					</select>
				  </p></td>
			  </tr>			  
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[footer-widgets-heading-font-color]"><?php _e('Text Color', CHILD_DOMAIN);?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input type="text" class="color_validate lander-color-selector" id="<?php
		echo $this->settings_field;
?>[footer-widgets-heading-font-color]" name="<?php
		echo $this->settings_field;
?>[footer-widgets-heading-font-color]" value="<?php
		echo genesis_get_option( 'footer-widgets-heading-font-color' ,$this->settings_field,false );
?>" />
				  </p></td>
			  </tr>
			  <tr>
				<td colspan="2"><h4 class="gl-head"><?php _e('Footer Widget Body', CHILD_DOMAIN);?></h4></td>
			  </tr>
			  
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field . '[footer-widgets-font-family]';
?>"><?php _e('Font Family', CHILD_DOMAIN);?></label>
				  </p></td>
				<td class="lander-input"><p>
					<?php
		echo '<select id="' . $this->settings_field . '[footer-widgets-font-family]" name="' . $this->settings_field . '[footer-widgets-font-family]">';
		$fwf = genesis_get_option( 'footer-widgets-font-family' ,$this->settings_field,false );
		foreach ( $this->lander_fonts as $font_key => $font ) {
			$selected = selected( $fwf , $font_key,0 );
			$web_safe = ( $font['web_safe'] ) ? ' *' : '';
			$google   = ( $font['google'] ) ? ' G' : '';
			echo "<option $selected value=\"$font_key\">" . $font['name'] . "$web_safe$google</option>\n";
		}
		echo '</select>';
?>
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[footer-widgets-font-size]"><?php _e('Font Size', CHILD_DOMAIN);?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input type="number" id="<?php
		echo $this->settings_field;
?>[footer-widgets-font-size]" name="<?php
		echo $this->settings_field;
?>[footer-widgets-font-size]" value="<?php
		echo genesis_get_option( 'footer-widgets-font-size' ,$this->settings_field,false );
?>" />&nbsp;px
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[footer-widgets-font-weight]"><?php _e('Font Weight', CHILD_DOMAIN);?></label>
				  </p></td>
				<td class="lander-input"><p>
				<?php
				$weights = lander_font_weights();
				$weight = genesis_get_option( 'footer-widgets-font-weight' ,$this->settings_field,false );
				?>
					<select id="<?php echo $this->settings_field;?>[footer-widgets-font-weight]" name="<?php echo $this->settings_field; ?>[footer-widgets-font-weight]">
					<?php
					foreach ($weights as $value) {
						echo '<option value="'.$value.'" '.selected($value,$weight,false).'>'.$value.'</option>';
					}
					?>
					</select>
				  </p></td>
			  </tr>			  
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[footer-widgets-font-color]"><?php _e('Text Color', CHILD_DOMAIN);?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input type="text" class="color_validate lander-color-selector" id="<?php
		echo $this->settings_field;
?>[footer-widgets-font-color]" name="<?php
		
		echo $this->settings_field;
?>[footer-widgets-font-color]" value="<?php
		echo genesis_get_option( 'footer-widgets-font-color' ,$this->settings_field,false );
?>" />
				  </p></td>
			  </tr>
			</table>
		  </div>
		</div>
		<?php
	}
	
	function footer_settings_box() {
?>
		<div class="gl-section">
		  <div class="gl-desc">
			<table class="gl-col-table">
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field . '[footer-font-family]';
?>"><?php _e('Font Family', CHILD_DOMAIN);?></label>
				  </p></td>
				<td class="lander-input"><p>
					<?php
		echo '<select id="' . $this->settings_field . '[footer-font-family]" name="' . $this->settings_field . '[footer-font-family]">';
		$ff = genesis_get_option( 'footer-font-family' ,$this->settings_field,false );
		foreach ( $this->lander_fonts as $font_key => $font ) {
			$selected = selected( $ff, $font_key,0 );
			$web_safe = ( $font['web_safe'] ) ? ' *' : '';
			$google   = ( $font['google'] ) ? ' G' : '';
			echo "<option $selected value=\"$font_key\">" . $font['name'] . "$web_safe$google</option>\n";
		}
		echo '</select>';
?>
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[footer-font-size]"><?php _e('Font Size', CHILD_DOMAIN);?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input type="number" min="8" max="72" id="<?php
		echo $this->settings_field;
?>[footer-font-size]" name="<?php
		echo $this->settings_field;
?>[footer-font-size]" value="<?php
		echo genesis_get_option( 'footer-font-size' ,$this->settings_field,false );
?>" />&nbsp;px
				  </p></td>
			  </tr>
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[footer-font-weight]"><?php _e('Font Weight', CHILD_DOMAIN);?></label>
				  </p></td>
				<td class="lander-input"><p>
				<?php
				$weights = lander_font_weights();
				$weight = genesis_get_option( 'footer-font-weight' ,$this->settings_field,false );
				?>
					<select id="<?php echo $this->settings_field;?>[footer-font-weight]" name="<?php echo $this->settings_field; ?>[footer-font-weight]">
					<?php
					foreach ($weights as $value) {
						echo '<option value="'.$value.'" '.selected($value,$weight,false).'>'.$value.'</option>';
					}
					?>
					</select>
				  </p></td>
			  </tr>			  
			  <tr>
				<td class="gl-label"><p>
					<label for="<?php
		echo $this->settings_field;
?>[footer-font-color]"><?php _e('Text Color', CHILD_DOMAIN);?></label>
				  </p></td>
				<td class="lander-input"><p>
					<input type="text" class="color_validate lander-color-selector" id="<?php
		echo $this->settings_field;
?>[footer-font-color]" name="<?php
		echo $this->settings_field;
?>[footer-font-color]" value="<?php
		echo genesis_get_option( 'footer-font-color' ,$this->settings_field,false );
?>" />
				  </p></td>
			  </tr>		
			</table>
		  </div>
		</div>
		<?php
	}

}

function lander_design_settings_menu() {
	global $_lander_admin_design_settings;
	$_lander_admin_design_settings = new Lander_Design_Settings;
}