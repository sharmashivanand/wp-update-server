<?php

function lander_extras_menu() {
	global $lander_extras;
	$lander_extras = new Lander_Extras;
}

class Lander_Extras extends Genesis_Admin_Boxes {
	
	function __construct() {
		
		$page_id  = CHILD_SETTINGS_FIELD_EXTRAS;
		
		$menu_ops = array(
			'submenu' => array(
				'parent_slug' => __( 'genesis', CHILD_DOMAIN ),
				'page_title' => __( 'Super Lander Admin', CHILD_DOMAIN ),
				'menu_title' => __( 'Super Lander Admin', CHILD_DOMAIN ) 
			)
		);
		
		$page_ops = array(
			'screen_icon' => 'themes',
		);
		
		$settings_field = CHILD_SETTINGS_FIELD_EXTRAS;
		$default_settings = lander_admin_defaults();
		
		$this->create( $page_id, $menu_ops, $page_ops,$settings_field,$default_settings );
		add_action( 'admin_print_styles', array(
			 $this,
			'styles' 
		) );
	
	}
	
	function styles(){
		wp_enqueue_style( 'lander-admin-style', CHILD_URL . '/lib/css/lander-admin.css' );
	}
	
	function metaboxes() {
		
		add_meta_box( 'lander_extras_design', __( 'Design Selector', CHILD_DOMAIN ), array( $this, 'customization_settings_box' ), $this->pagehook, 'main' );
		
		add_meta_box( 'lander_widget_settings_box', __( 'Widget Areas', CHILD_DOMAIN ), array( $this, 'widget_settings_box' ), $this->pagehook, 'main' );
		
		add_meta_box( 'lander_mobile_landing_box', __( 'Mobile Template Settings', CHILD_DOMAIN ), array( $this, 'lander_mobile_settings_box' ), $this->pagehook, 'main' );
		
		add_meta_box( 'lander_extras_webmasters', __( 'Webmaster\'s Checklist',  CHILD_DOMAIN ), array( $this, 'lander_startup_guide' ), $this->pagehook, 'main' );

	}
	
	function save( $newsettings, $oldsettings ) {
		
		$design_field = isset( $newsettings['design'] ) ? $newsettings['design'] : 'vanilla';		
		$customization = $design_field;
		$all_customizations = lander_customization_aggregator();
		
		if( is_array( $all_customizations ) && array_key_exists( $design_field, $all_customizations ) ) {
			$current_customization = $all_customizations[ $design_field ];		
			if ( is_array( $current_customization ) && array_key_exists( 'functions', $current_customization ) ) {
				include_once( $current_customization[ 'functions' ] );
			}
		}
		
		lander_init_css( get_option( CHILD_SETTINGS_FIELD . '-' . $design_field ) );		
		
		if( isset( $newsettings['new-design'] ) && ! empty( $newsettings['new-design'] ) ) {
			$new_design = lander_ws($newsettings['new-design']);			
			if( ! empty( $new_design ) ) {
				lander_init_path( LANDER_USER_DESIGNS . '/' . $new_design );
				touch( LANDER_USER_DESIGNS . '/' . $new_design . '/functions.php' );
				touch( LANDER_USER_DESIGNS . '/' . $new_design . '/style.scss' );
				$newsettings['design'] = $new_design;				
			}
		}
		
		return $newsettings;
		
	}
	
	function scripts() {
		
		parent::scripts();
		genesis_load_admin_js();		
		wp_enqueue_script( 'lander-admin-js', CHILD_URL . '/lib/js/lander-admin.js' );		
		wp_localize_script( 'lander-admin-js', CHILD_DOMAIN, array(
			'pageHook'      => $this->pagehook,
			'firstTime'     => ! is_array( get_user_option( 'closedpostboxes_' . $this->pagehook ) ),
		) );
			
	}
	
	
	function customization_settings_box() {
		$lander_customizations = lander_customization_aggregator();
		?>
		<div class="gl-section">
		<div class="gl-desc">
		<table class="gl-col-table">
			<tr>
			<td colspan="2">
				<p class="l-desc"><label><?php _e('Please select a design to use. The following designs are available.',CHILD_DOMAIN ); ?></label></p>
			</td>
			</tr>
			
			<tr>
			<td class="gl-label">
				<p>
				<label for="<?php echo $this->settings_field . '[design]'; ?>"><?php _e( 'Designs', CHILD_DOMAIN ); ?></label>
				</p>
			</td>
			<td class="lander-input">
				<p>
				<?php
				if ( is_array( $lander_customizations ) ) {
					echo '<select class="customization" id="' . $this->settings_field . '[design]" name="' . $this->settings_field . '[design]">';
					$current_customization = genesis_get_option( 'design',$this->settings_field,false );
					foreach ( $lander_customizations as $key => $value ) {
						$selected = selected( $current_customization, $key, 0 );
						echo '<option ' . $selected . ' value="' . $key . '">' . $value['name'] . '</option>' . "\n";
					}
					echo '</select>';
				}
				else {
					_e('Currently there are no customizations. But you can create one.',CHILD_DOMAIN);
				}
				?>
				</p>
			</td>					  
			</tr>
			
			<tr>
			<td colspan="2">
				<p>
				<?php printf( __( 'Please go to <a href="%s" >Super Lander Design</a> to set up the initial design.', CHILD_DOMAIN ), esc_url( menu_page_url( lander_get_design_page_id(),0 ) ) ); ?>
				</p>
				<?php
				$current_design = genesis_get_option( 'design', $this->settings_field, false );
				if( is_array( $lander_customizations ) && array_key_exists( $current_design, $lander_customizations ) ) {
					$current_design = $lander_customizations[$current_design];
					if( $current_design['type'] != 'core' ) {
						echo '<p>' . __( 'Please edit the following file(s) to customize the design further.', CHILD_DOMAIN ) . '</p>';
						
						if( array_key_exists( 'functions', $current_design ) ) {
							echo '<pre>&#9632;&nbsp;' . str_ireplace( ABSPATH, '', $current_design['functions'] ) . '</pre>';
						}
						
						if( array_key_exists( 'sass', $current_design ) ) {
							$path = str_ireplace( ABSPATH, '', $current_design['functions'] );
							$path = str_ireplace( 'functions.php', 'style.scss', $path );
							echo '<pre>&#9632;&nbsp;' . $path . '</pre>';
						}								
					}
				}
				?>
			</td>
			</tr>
			
			<tr>
			<td class="gl-label">
				<p class="l-desc">
				<label><?php _e( 'Or create a new design', CHILD_DOMAIN ); ?></label>
				</p>
			</td>
			<td class="lander-input">
				<p>
				<input class="new-design" type="text" id="<?php echo $this->settings_field; ?>[new-design]" name="<?php echo $this->settings_field; ?>[new-design]" value="<?php ?>" />
				</p>
			</td>
			</tr>
		</table>
		</div>
		</div>
		<?php
	}
	
	function widget_settings_box() {

	?>  
		<div class="gl-section">
		<div class="gl-desc">
		<table class="gl-cta-table">
			<tr>
			<td class="gl-label">
				<p>
				<label for="<?php echo $this->settings_field . '[footer-widgets]'; ?>"><?php _e('Footer Widgets', CHILD_DOMAIN ); ?></label>
				</p>
			</td>
			<td class="lander-input">
				<p>
				<?php
				$fwnum = array(
					'enable',
					'disable' 
				);
				echo '<select id="' . $this->settings_field . '[footer-widgets]" name="' . $this->settings_field . '[footer-widgets]">';
				$fwn = genesis_get_option( 'footer-widgets' ,$this->settings_field,false );
				
				foreach ( $fwnum as $wnum ) {
					echo "<option " . selected( $wnum, $fwn, false ) . " value=\"$wnum\">" . ucwords( $wnum ) . "</option>\n";
				}
				echo '</select>';
				?>
				</p>
			</td>
			</tr>
		
			<tr>
			<td class="gl-label">
				<p>
				<?php _e( 'Widgets Above Header', CHILD_DOMAIN ); ?>
				</p>
			</td>
			<td class="lander-input">
				<p>						
				<?php if ( 'page' === get_option( 'show_on_front' ) ) { ?>

					<label for="<?php echo $this->get_field_id( 'widgets_before_header_front' ) ?>"><input value="1" <?php checked( $this->get_field_value( 'widgets_before_header_front' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_before_header_front' ); ?>" id="<?php echo $this->get_field_id( 'widgets_before_header_front' ); ?>" /><?php _e( 'Front Page', CHILD_DOMAIN ); ?></label>
					
					<label for="<?php echo $this->get_field_id('widgets_before_header_posts_page')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_before_header_posts_page' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_before_header_posts_page' ); ?>" id="<?php echo $this->get_field_id( 'widgets_before_header_posts_page' ); ?>" /><?php _e( 'Posts Page', CHILD_DOMAIN ); ?></label>										
				
				<?php }
				else {
				?>
					<label for="<?php echo $this->get_field_id( 'widgets_before_header_home' )?>"><input value="1" <?php checked( $this->get_field_value( 'widgets_before_header_home' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_before_header_home' ); ?>" id="<?php echo $this->get_field_id( 'widgets_before_header_home' ); ?>" /><?php _e( 'Home Page', CHILD_DOMAIN ); ?></label>
				<?php } ?>
				
				<label for="<?php echo $this->get_field_id( 'widgets_before_header_post' )?>"><input value="1" <?php checked( $this->get_field_value( 'widgets_before_header_post' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_before_header_post' ); ?>" id="<?php echo $this->get_field_id( 'widgets_before_header_post' ); ?>" /><?php _e( 'Post', CHILD_DOMAIN ); ?></label>
				
				<label for="<?php echo $this->get_field_id( 'widgets_before_header_page' )?>"><input value="1" <?php checked( $this->get_field_value( 'widgets_before_header_page' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_before_header_page' ); ?>" id="<?php echo $this->get_field_id( 'widgets_before_header_page' ); ?>" /><?php _e( 'Page', CHILD_DOMAIN ); ?></label>
				
				<label for="<?php echo $this->get_field_id( 'widgets_before_header_archives' )?>"><input value="1" <?php checked( $this->get_field_value( 'widgets_before_header_archives' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_before_header_archives' ); ?>" id="<?php echo $this->get_field_id( 'widgets_before_header_archives' ); ?>" /><?php _e( 'Archives', CHILD_DOMAIN ); ?></label>

				<label for="<?php echo $this->get_field_id( 'widgets_before_header_404' )?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_before_header_404' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_before_header_404' ); ?>" id="<?php echo $this->get_field_id( 'widgets_before_header_404' ); ?>" /><?php _e( '404', CHILD_DOMAIN ); ?></label>
				</p>
			</td>					  
			</tr>
		
			<tr>
			<td class="gl-label">
				<p><?php _e( 'Widgets Below Header', CHILD_DOMAIN ); ?></p>
			</td>
			
			<td class="lander-input">
				<p>						
				<?php if ( 'page' === get_option( 'show_on_front' ) ) { ?>
					<label for="<?php echo $this->get_field_id( 'widgets_after_header_front' )?>"><input value="1" <?php checked( $this->get_field_value( 'widgets_after_header_front' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_after_header_front' ); ?>" id="<?php echo $this->get_field_id( 'widgets_after_header_front' ); ?>" /><?php _e( 'Front Page', CHILD_DOMAIN ); ?></label>
					
					<label for="<?php echo $this->get_field_id( 'widgets_after_header_posts_page' )?>"><input value="1" <?php checked( $this->get_field_value( 'widgets_after_header_posts_page' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_after_header_posts_page' ); ?>" id="<?php echo $this->get_field_id( 'widgets_after_header_posts_page' ); ?>" /><?php _e( 'Posts Page', CHILD_DOMAIN ); ?></label>										
				<?php }
				else {
				?>
					<label for="<?php echo $this->get_field_id( 'widgets_after_header_home' )?>"><input value="1" <?php checked( $this->get_field_value( 'widgets_after_header_home' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_after_header_home' ); ?>" id="<?php echo $this->get_field_id( 'widgets_after_header_home' ); ?>" /><?php _e( 'Home Page', CHILD_DOMAIN ); ?></label>
				<?php } ?>
			
				<label for="<?php echo $this->get_field_id( 'widgets_after_header_post' )?>"><input value="1" <?php checked( $this->get_field_value( 'widgets_after_header_post' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_after_header_post' ); ?>" id="<?php echo $this->get_field_id( 'widgets_after_header_post' ); ?>" /><?php _e( 'Post', CHILD_DOMAIN ); ?></label>
			
				<label for="<?php echo $this->get_field_id( 'widgets_after_header_page' )?>"><input value="1" <?php checked( $this->get_field_value( 'widgets_after_header_page' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_after_header_page' ); ?>" id="<?php echo $this->get_field_id( 'widgets_after_header_page' ); ?>" /><?php _e( 'Page', CHILD_DOMAIN ); ?></label>
				
				<label for="<?php echo $this->get_field_id( 'widgets_after_header_archives' )?>"><input value="1" <?php checked( $this->get_field_value( 'widgets_after_header_archives' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_after_header_archives' ); ?>" id="<?php echo $this->get_field_id( 'widgets_after_header_archives' ); ?>" /><?php _e( 'Archives', CHILD_DOMAIN ); ?></label>
			
				<label for="<?php echo $this->get_field_id( 'widgets_after_header_404' )?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_after_header_404' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_after_header_404' ); ?>" id="<?php echo $this->get_field_id( 'widgets_after_header_404' ); ?>" /><?php _e( '404', CHILD_DOMAIN ); ?></label>
				</p>
			</td>					  
			</tr>
				
			<tr>
			<td class="gl-label">
				<p><?php _e( 'Widgets Above Footer',CHILD_DOMAIN ); ?></p>
			</td>
			
			<td class="lander-input">
				<p>						
				<?php if ( 'page' === get_option( 'show_on_front' ) ) { ?>
					<label for="<?php echo $this->get_field_id( 'widgets_above_footer_front' )?>"><input value="1" <?php checked( $this->get_field_value( 'widgets_above_footer_front' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_above_footer_front' ); ?>" id="<?php echo $this->get_field_id( 'widgets_above_footer_front' ); ?>" /><?php _e( 'Front Page', CHILD_DOMAIN ); ?></label>				
					
					<label for="<?php echo $this->get_field_id( 'widgets_above_footer_posts_page' )?>"><input value="1" <?php checked( $this->get_field_value( 'widgets_above_footer_posts_page' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_above_footer_posts_page' ); ?>" id="<?php echo $this->get_field_id( 'widgets_above_footer_posts_page' ); ?>" /><?php _e( 'Posts Page', CHILD_DOMAIN ); ?></label>										
				<?php }
				else {
				?>
					<label for="<?php echo $this->get_field_id( 'widgets_above_footer_home' )?>"><input value="1" <?php checked( $this->get_field_value( 'widgets_above_footer_home' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_above_footer_home' ); ?>" id="<?php echo $this->get_field_id( 'widgets_above_footer_home' ); ?>" /><?php _e( 'Home Page', CHILD_DOMAIN ); ?></label>
				<?php } ?>
				
				<label for="<?php echo $this->get_field_id( 'widgets_above_footer_post' )?>"><input value="1" <?php checked( $this->get_field_value( 'widgets_above_footer_post' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_above_footer_post' ); ?>" id="<?php echo $this->get_field_id( 'widgets_above_footer_post' ); ?>" /><?php _e( 'Post', CHILD_DOMAIN ); ?></label>
			
				<label for="<?php echo $this->get_field_id( 'widgets_above_footer_page' )?>"><input value="1" <?php checked( $this->get_field_value( 'widgets_above_footer_page' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_above_footer_page' ); ?>" id="<?php echo $this->get_field_id( 'widgets_above_footer_page' ); ?>" /><?php _e( 'Page', CHILD_DOMAIN ); ?></label>
			
				<label for="<?php echo $this->get_field_id( 'widgets_above_footer_archives' )?>"><input value="1" <?php checked( $this->get_field_value( 'widgets_above_footer_archives' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_above_footer_archives' ); ?>" id="<?php echo $this->get_field_id( 'widgets_above_footer_archives' ); ?>" /><?php _e( 'Archives', CHILD_DOMAIN ); ?></label>
				
				<label for="<?php echo $this->get_field_id( 'widgets_above_footer_404' )?>"><input value="1" <?php checked( $this->get_field_value( 'widgets_above_footer_404' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_above_footer_404' ); ?>" id="<?php echo $this->get_field_id( 'widgets_above_footer_404' ); ?>" /><?php _e( '404', CHILD_DOMAIN ); ?></label>
				</p>
			</td>					  
			</tr>
				 			 
		</table>
		</div>
		</div>
		<?php

	}
	
	function lander_mobile_settings_box() {
		
		?>
		<p>Use these settings to globally enable disable certain elements on the site. These settings will only take effect when user is viewing the site on a mobile viewport.</p>
		<p><em>Note: You can also change these settings on a per page / post basis using the <strong>Mobile Landing Page Experience</strong> metabox on the page / post edit screen.</em></p>
		<div class="gl-section">
		<div class="gl-desc">
		<table>
			<tr>
				<td class="gl-label">
				<p><label for="<?php $this->field_id( 'mlp_hide_header' ); ?>"><?php _e( 'Hide Header', CHILD_DOMAIN ); ?></label></p>
				</td>
				<td>
				<p><input type="checkbox" id="<?php $this->field_id( 'mlp_hide_header' ); ?>" name="<?php $this->field_name( 'mlp_hide_header' ); ?>" value="1" <?php checked( $this->get_field_value( 'mlp_hide_header' ) ); ?> /></p>
				</td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php $this->field_id( 'mlp_hide_breadcrumbs' ); ?>"><?php _e( 'Hide Breadcrumbs', CHILD_DOMAIN ); ?></label></p>
				</td>
				<td>
				<p><input type="checkbox" id="<?php $this->field_id( 'mlp_hide_breadcrumbs' ); ?>" name="<?php $this->field_name( 'mlp_hide_breadcrumbs' ); ?>" value="1" <?php checked( $this->get_field_value( 'mlp_hide_breadcrumbs' ) ); ?> /></p>
				</td>
				<td id="lander-breadcrumb-notice" class="notice notice-warning inline">
				<p><?php printf( __( 'Make sure you have enabled breadcrumbs on <a href="%s" target="_blank">Genesis Theme Settings</a> page.', CHILD_DOMAIN ), menu_page_url( 'genesis', false ) ) ?></p>
				</td>
			</tr>
			
		
			<tr>	
				<td class="gl-label">
				<p><label for="<?php $this->field_id( 'mlp_hide_page_title' ); ?>"><?php _e( 'Hide Page Title', CHILD_DOMAIN ); ?></label></p>
				</td>
				<td>
				<p><input type="checkbox" id="<?php $this->field_id( 'mlp_hide_page_title' ); ?>" name="<?php $this->field_name( 'mlp_hide_page_title' ); ?>" value="1" <?php checked( $this->get_field_value( 'mlp_hide_page_title' ) ); ?> /></p>
				</td>
			</tr>
			
			<tr>
				<td class="gl-label">
				<p><label for="<?php $this->field_id( 'mlp_hide_sec_title' ); ?>"><?php _e( 'Hide Secondary Title', CHILD_DOMAIN ); ?></label></p>
				</td>
				<td>
				<p><input type="checkbox" id="<?php $this->field_id( 'mlp_hide_sec_title' ); ?>" name="<?php $this->field_name( 'mlp_hide_sec_title' ); ?>" value="1" <?php checked( $this->get_field_value( 'mlp_hide_sec_title' ) ); ?> /></p>
				</td>
			</tr>
			
			<?php
			$global_fwidgets = genesis_get_option( 'footer-widgets', CHILD_SETTINGS_FIELD_EXTRAS, false );
			
			if( $global_fwidgets == 'enable' ) {
				?>
				<tr>
					<td class="gl-label">
					<p><label for="<?php $this->field_id( 'mlp_hide_fwidgets' ); ?>"><?php _e( 'Hide Footer Widgets', CHILD_DOMAIN ); ?></label></p>
					</td>
					<td>
					<p><input type="checkbox" id="<?php $this->field_id( 'mlp_hide_fwidgets' ); ?>" name="<?php $this->field_name( 'mlp_hide_fwidgets' ); ?>" value="1" <?php checked( $this->get_field_value( 'mlp_hide_fwidgets' ) ); ?> /></p>
					</td>
				</tr>
				<?php
			}
			?>
				
			<tr>
				<td class="gl-label">
				<p><label for="<?php $this->field_id( 'mlp_hide_hfwidgets' ); ?>"><?php _e( 'Hide Horizontal Footer Widgets', CHILD_DOMAIN ); ?></label></p>
				</td>
				<td>
				<p><input type="checkbox" id="<?php $this->field_id( 'mlp_hide_hfwidgets' ); ?>" name="<?php $this->field_name( 'mlp_hide_hfwidgets' ); ?>" value="1" <?php checked( $this->get_field_value( 'mlp_hide_hfwidgets' ) ); ?> /></p>
				</td>
			</tr>

			<tr>
				<td class="gl-label">
				<p><label for="<?php $this->field_id( 'mlp_hide_footer' ); ?>"><?php _e( 'Hide Footer', CHILD_DOMAIN ); ?></label></p>
				</td>
				<td>
				<p><input type="checkbox" id="<?php $this->field_id( 'mlp_hide_footer' ); ?>" name="<?php $this->field_name( 'mlp_hide_footer' ); ?>" value="1" <?php checked( $this->get_field_value( 'mlp_hide_footer' ) ); ?> /></p>
				</td>
			</tr>
		</table>
		</div>
		</div>
		<?php

	}
	
	function lander_startup_guide() {
	
		?>
		<p><?php _e( 'Here\'s a small checklist to help you make sure that your site is ready to flaunt the Super Lander awesomeness: (So that we don\'t lose you, all links open in new pages.)', CHILD_DOMAIN ); ?></p>
		
		<ol>		
			<li>
			<?php _e( 'Make sure you are not using the WordPress default tagline "Just another WordPress blog". It will affect your meta description. ', CHILD_DOMAIN); ?>
			</li>
			
			<li>
			<?php printf( __( 'Visit <a target="_blank" href="%s">Genesis SEO settings</a> and ensure that you have a homepage document title and meta description set.', CHILD_DOMAIN ), menu_page_url( 'seo-settings', false ) ); ?>
			</li>
			
			<li>
			<?php _e( 'Enable Google Authorship and/or Publisher markup and verify at Google\'s <a target="_blank" href="http://www.google.com/webmasters/tools/richsnippets">Structured Data Testing Tool</a>.', CHILD_DOMAIN ); ?>
			</li>
			
			<li>
			<?php printf( __( 'How does your 404 Page look? Visit <a target="_blank" href="%s">this page</a> (<em>Recommended</em>).', CHILD_DOMAIN ), get_home_url() . '/?p=' . time() ); ?>
			</li>
			
			<li>
			<?php printf( __( 'Enable pretty <a target="_blank" href="%s">permalinks</a> under permalink settings.', CHILD_DOMAIN ), get_admin_url() . 'options-permalink.php' ); ?>
			</li>
			
			<li>
			<?php printf( __( 'Setup and integrate <a target="_blank" href="http://www.google.com/analytics/">Google Analytics</a>. Place the code under <a target="_blank" href="%s">Genesis Theme Settings</a> into the header scripts (wp_head) box.', CHILD_DOMAIN ), menu_page_url( 'genesis', false ) ); ?>
			</li>
			
			<li>
			<?php _e( 'Verify your site at <a target="_blank" href="http://www.google.com/webmasters/">Google Webmasters</a> and <a target="_blank" href="http://www.bing.com/toolbox/webmaster">Bing Webmasters</a> setup. Also submit your xml sitemap (if you have one).', CHILD_DOMAIN ); ?>
			</li>
			
			<li>
			<?php printf( __( 'If your website doesn’t have a favicon yet, you can <a target="_blank" href="%s">set one here</a>.', CHILD_DOMAIN ), menu_page_url( CHILD_SETTINGS_FIELD_BRANDING, false ) ); ?>
			</li>
			
			<li>
			<?php printf( __( 'Uncheck Discourage search engines from indexing this site option under <a target="_blank" href="%s">reading settings</a> so that search bots can index your site.', CHILD_DOMAIN ), get_admin_url() . 'options-reading.php'); ?>
			</li>
		</ol>		
		<p><?php _e( 'Optionally&hellip;', CHILD_DOMAIN ); ?></p>		
		<ul>
			<li><?php _e( 'Setup RSS feed / Feedburner / Aweber / Mailchimp.', CHILD_DOMAIN); ?></li>		
		</ul>
		<?php
	}
}
