<?php
/*
Template Name: Nice Template
*/