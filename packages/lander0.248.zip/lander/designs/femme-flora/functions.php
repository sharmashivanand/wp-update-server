<?php

genesis_register_widget_area( array(
	 'id' => 'after-header-widget',
	'name' => __( 'After Header Widgets', 'lander' ),
	'description' => __( 'This widget can be used to display the desired content, after the header on your site.', 'lander' ),
	'before_title' => '<h4>',
	'after_title' => '</h4>' 
) );

add_action( 'genesis_after_header', 'lander_ff_after_header' );

function lander_ff_after_header() { 
	if(is_active_sidebar('after-header-widget')){
		echo '<div class="ff-portfolio-area"><div class="wrap">';
		genesis_widget_area( 'after-header-widget', array(
			'before' => '<div class="widget-after-header entry-content widget-area">',
			'after' => '</div>' 
			) 
		);
		echo '</div></div>';
	}
}

add_filter('lander_settings_css','femme_css',10,2);

function femme_css($css,$settings) {
	//$settings['nav-menu-link-bg-color'];
	$css = $css . 'body.lander.pagewidth .nav-primary .wrap{padding-bottom:0;padding-top:0;background-color:'.$settings['nav-menu-link-bg-color'].';}';
	$css = $css . 'body.lander.fullwidth .nav-primary .wrap, body.lander.fullwidth .nav-primary .menu-primary{background-color:'.$settings['nav-menu-link-bg-color'].';}';
	$css = $css . 'body.lander.pagewidth .menu-primary{margin-left:-1em;margin-right:-1em}';
	$css = $css . 'body.lander.pagewidth .nav-secondary .wrap{padding-bottom:0;padding-top:0.809em;background-color:'.$settings['subnav-menu-link-bg-color'].'}';
	$css = $css . 'body.lander.fullwidth .nav-secondary .wrap, body.lander.fullwidth .nav-secondary .menu-secondary{background-color:'.$settings['nav-menu-link-bg-color'].';}';
	$css = $css . 'body.lander.pagewidth .menu-secondary{margin-left:-1em;margin-right:-1em}';
	return $css;
}

add_filter('lander_design_defaults','femme_flora_defaults');

function femme_flora_defaults($defaults){
	$defaults['layout']='pagewidth';
	$defaults['col-spacing']='35';
	$defaults['column-content-1col']='730';
	$defaults['column-content-2col']='505';
	$defaults['sidebar-one-2col']='190';
	$defaults['column-content-3col']='280';
	$defaults['sidebar-one-3col']='190';
	$defaults['sidebar-two-3col']='190';
	$defaults['body-font-family']='helvetica';
	$defaults['content-area-font-size']='14';
	$defaults['content-area-font-weight']='normal';
	$defaults['site-background-color']='#bbb';
	$defaults['page-background-color']='#ffffff';
	$defaults['primary-text-color']='#333';
	$defaults['primary-link-color']='#2361A1';
	$defaults['primary-link-hover-color']='#2361A1';
	$defaults['header-area-font-color']='#fff';
	$defaults['header-area-font-size']='60';
	$defaults['header-area-font-weight']='normal';
	$defaults['header-area-font-family']='times_new_roman';
	$defaults['header-area-tagline-font-color']='#eee';
	$defaults['header-area-tagline-font-size']='14';
	$defaults['header-area-tagline-font-weight']='normal';
	$defaults['header-area-tagline-font-family']='_inherit';
	$defaults['headline-font-color']='#bf7393';
	$defaults['headline-font-weight']='normal';
	$defaults['headline-font-size']='36';
	$defaults['headline-font-family']='times_new_roman';
	$defaults['headline-subhead-font-color']='#bf7393';
	$defaults['headline-subhead-font-weight']='bold';
	$defaults['headline-subhead-font-family']='_inherit';
	$defaults['nav-menu-font-family']='_inherit';
	$defaults['nav-menu-font-size']='13';
	$defaults['nav-menu-font-weight']='bold';
	$defaults['nav-menu-link-text-color']='#fff';
	$defaults['nav-menu-link-text-hover-color']='#fff';
	$defaults['nav-menu-current-link-text-color']='#fff';
	$defaults['nav-menu-current-parent-link-text-color']='#fff';
	$defaults['nav-menu-link-bg-color']='#d982a6';
	$defaults['nav-menu-hover-bg-color']='#bf7393';
	$defaults['nav-menu-current-bg-color']='#bf7393';
	$defaults['nav-menu-current-parent-bg-color']='#bf7393';
	$defaults['nav-menu-border-width']='0';
	$defaults['nav-menu-border-color']='#eee';
	$defaults['nav-menu-submenu-width']='150';
	$defaults['subnav-menu-font-family']='_inherit';
	$defaults['subnav-menu-font-size']='13';
	$defaults['subnav-menu-font-weight']='bold';
	$defaults['subnav-menu-link-text-color']='#fff';
	$defaults['subnav-menu-link-text-hover-color']='#fff';
	$defaults['subnav-menu-current-link-text-color']='#ffffff';
	$defaults['subnav-menu-current-parent-link-text-color']='#fff';
	$defaults['subnav-menu-link-bg-color']='#d982a6';
	$defaults['subnav-menu-hover-bg-color']='#bf7393';
	$defaults['subnav-menu-current-bg-color']='#bf7393';
	$defaults['subnav-menu-current-parent-bg-color']='#bf7393';
	$defaults['subnav-menu-border-width']='0';
	$defaults['subnav-menu-border-color']='#eee';
	$defaults['subnav-menu-submenu-width']='150';
	$defaults['byline-font-family']='_inherit';
	$defaults['byline-font-color']='#b3597e';
	$defaults['byline-font-size']='11';
	$defaults['code-font-color']='#111111';
	$defaults['code-font-size']='12';
	$defaults['code-font-family']='consolas';
	$defaults['sidebar-font-family']='_inherit';
	$defaults['sidebar-font-color']='#808080';
	$defaults['sidebar-font-size']='14';
	$defaults['sidebar-font-weight']='normal';
	$defaults['sidebar-heading-font-family']='times_new_roman';
	$defaults['sidebar-heading-font-size']='16';
	$defaults['sidebar-heading-font-weight']='normal';
	$defaults['sidebar-heading-font-color']='#bf7393';
	$defaults['footer-widgets']='enable';
	$defaults['footer-widgets-font-family']='_inherit';
	$defaults['footer-widgets-font-color']='#808080';
	$defaults['footer-widgets-font-size']='14';
	$defaults['footer-widgets-font-weight']='normal';
	$defaults['footer-widgets-heading-font-family']='times_new_roman';
	$defaults['footer-widgets-heading-font-size']='16';
	$defaults['footer-widgets-heading-font-weight']='normal';
	$defaults['footer-widgets-heading-font-color']='#b3597e';
	$defaults['footer-font-family']='_inherit';
	$defaults['footer-font-color']='#aaa';
	$defaults['footer-font-size']='12';
	$defaults['footer-font-weight']='normal';
	return $defaults;
}