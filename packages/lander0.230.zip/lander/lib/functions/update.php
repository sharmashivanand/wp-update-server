<?php
add_action( 'admin_init', 'lander_update', 20 );
add_action( 'lander_update', 'lander_update_redirect' );
add_action( 'admin_notices', 'lander_welcome', 1 );
add_action( 'load-update-core.php', 'lander_clear_update_transient' );
add_action( 'admin_notices', 'lander_update_nag' );
add_filter( 'update_theme_complete_actions', 'lander_update_action_links', 10, 2 );
add_filter( 'update_bulk_theme_complete_actions', 'lander_update_action_links', 10, 2 );
add_filter( 'site_transient_update_themes', 'lander_update_push' );
add_filter( 'transient_update_themes', 'lander_update_push' );


function lander_update_check() {
	global $wp_version;
	
	$lander_license_key = genesis_get_option('license',CHILD_SETTINGS_FIELD_EXTRAS);
	
	$lander_update = get_transient( 'lander-update' );
	
	if ( !$lander_update ) {
		$url     = 'https://www.binaryturf.com/files/wus/?action=get_metadata&slug=lander';
		$options = apply_filters( 'lander_update_remote_post_options', array(
			 'body' => array(
				'lander_version' => CHILD_THEME_VERSION,
				'genesis_version' => PARENT_THEME_VERSION,
				'wp_version' => $wp_version,
				'php_version' => phpversion(),
				'license_key' => $lander_license_key,
				'uri' => home_url(),
				'user-agent' => "WordPress/$wp_version;" 
			) 
		) );
		
		$response      = wp_remote_post( $url, $options );
		$lander_update = wp_remote_retrieve_body( $response );
		$status        = wp_remote_retrieve_response_code( $response );
		if ( $status != '200' || 'error' == $lander_update || is_wp_error( $lander_update ) ) {
			set_transient( 'lander-update', array(
				 'new_version' => CHILD_THEME_VERSION 
			), 60 * 60 );
			return false;
		}		
		$lander_update = (array) json_decode( $lander_update );		
		$lander_update = lander_sanitize( $lander_update );		
		set_transient( 'lander-update', $lander_update, 60 * 60 * 24 );
	}	
	if ( version_compare( CHILD_THEME_VERSION, $lander_update['new_version'], '>=' ) )
		return false;
	return $lander_update;
	
}

function lander_sanitize( $lander_update ) {
	if ( isset( $lander_update['version'] ) ) {
		$lander_update['new_version'] = $lander_update['version'];
	}
	if ( isset( $lander_update['download_url'] ) ) {
		$lander_update['package'] = $lander_update['download_url'];
	}
	if ( isset( $lander_update['author_homepage'] ) ) {
		$lander_update['url'] = $lander_update['author_homepage'];
	}	
	foreach ( $lander_update as $key => $value ) {
		if ( $key != 'url' && $key != 'package' && $key != 'new_version' ) {
			unset( $lander_update[$key] );
		}
	}
	ksort( $lander_update );
	return $lander_update;
}

//A) checks the $_REQUEST in the url and ensures the settings-version is updated to the latest on manual options submission
//B) executes the lander_update hook with the installated/updated as a parameter
//C) if something is hooked to the above hook like a redirect page then a redirect is initiated
function lander_update() {
	$action = false;
	$set = genesis_get_option( 'settings-version',CHILD_SETTINGS_FIELD_EXTRAS, false );
	
	//settings-updated means the options page was submitted
	//reset means the options page was reset
	//error means the options page was submitted and caused an error?
	
	//if this is a user submitted screen then insert the settings-version to the submission (since that field in not present in the options form) and return.
	$userAction = isset( $_REQUEST['settings-updated'] ) || isset( $_REQUEST['reset'] ) || isset( $_REQUEST['error'] );
	if ( $userAction ) {
		genesis_update_settings( array(
			 'settings-version' => CHILD_THEME_VERSION 
		), CHILD_SETTINGS_FIELD_EXTRAS );
		return;
	}

	//else if this is not a user triggered submittion or is an admin page load then do an version comparison and trigger the required action
	
	//mixed version_compare ( $set , CHILD_THEME_VERSION [, string $operator ] )
	//By default, version_compare() returns -1 if $set is lower than CHILD_THEME_VERSION, 0 if they are equal, and 1 if the CHILD_THEME_VERSION is lower.
	
	$compare = version_compare( $set,CHILD_THEME_VERSION );
		
	if($compare == 0)	// both are equal
		{
		return;
		//$action = 'updated';
	}
	if($set == 'false'){		
		$set = false;
		$action = 'installed';
	}
	else{
		if($compare == -1){
			$action = 'updated';
		}
	}
	
	if ($action == 'installed' || $action == 'updated' ) {
		do_action( 'lander_update', $action );
	}
}


//redirect to the admin page after update/install
function lander_update_redirect( $action = 'installed' ) {	
	
	if ( !is_admin() ) {
		return;
	}	
	
	if (( !( defined( 'DOING_AJAX' ) && DOING_AJAX ) )) {
		lander_generate_css();	//get the css settings and write/update the settings file
		
		//if(isset( $_REQUEST['updated'] ) && 'true' == $_REQUEST['updated']) {
		//llog('<h2 style="background:red">Update required</h2>');
		//upgrade the design settings
		$design_settings = lander_back_compat(get_option(lander_get_design_page_id()));			
		update_option($design_settings,lander_get_design_page_id());
		
		//upgrade admin settings
		$lander_admin_settings = wp_parse_args( get_option(CHILD_SETTINGS_FIELD_EXTRAS), lander_admin_defaults() );
		
		update_option(CHILD_SETTINGS_FIELD_EXTRAS,$lander_admin_settings);

		//on upgrade previous setting-version isn't overwritten with old one. So here's a manual update.
		genesis_update_settings( array(
				 'settings-version' => CHILD_THEME_VERSION 
			), CHILD_SETTINGS_FIELD_EXTRAS );
		if (current_theme_supports( 'lander-deploy' ) 
			|| current_theme_supports( 'lander-admin-deploy' ) ) {
			return;	
		}
		genesis_admin_redirect( CHILD_SETTINGS_FIELD_EXTRAS, array( $action => 'true' ) );
		exit;
	}
}


//Show welcome messages when installed/updated
function lander_welcome() {
	if ( !genesis_is_menu_page( 'genesis_page_'.CHILD_SETTINGS_FIELD_EXTRAS ) ) {
		return;
	}
	
	if ( isset( $_REQUEST['updated'] ) && 'true' == $_REQUEST['updated'] ) {
		?>
		<div class="updated" style="background-color:#fea;">
			<p><?php
			_e( '<span style="updated lander-first-run-notice"><strong>Lander Updated. &mdash; You\'re all set to flaunt the new goods!</strong></span>', CHILD_DOMAIN );?>
			</p>
		</div>
		<?php
	}
	else {
		if ( isset( $_REQUEST['installed'] ) && 'true' == $_REQUEST['installed'] ) {
		?>
			<div class="updated" style="background-color:#fea;">
				<p><?php
				echo '<span class="installed lander-first-run-notice"><strong>'. __('You\'re now rocking Lander &mdash; Featuring insanely powerful landing pages and a tight control over your site design!' , CHILD_DOMAIN) .'</strong></span>';
				?>
				</p>
			</div>
			<?php
		}
	}
}



function lander_update_action_links( $actions, $theme ) {
	
	if(is_object($theme)){
		$theme = $theme->get_stylesheet();		
	}
	
	if ( 'lander' != $theme ) {
		return $actions;
	}
	
	if (current_theme_supports( 'lander-deploy' ) 
			|| current_theme_supports( 'lander-admin-deploy' ) ) {
			return $actions;
		}
		
	return sprintf( '<a href="%s">%s</a>', menu_page_url( CHILD_SETTINGS_FIELD_EXTRAS, 0 ).'&updated=true', __( 'Click here to complete the upgrade', CHILD_DOMAIN ) );
	
}



function lander_update_push( $value ) {
	if ( defined( 'DISALLOW_FILE_MODS' ) && true == DISALLOW_FILE_MODS )
		return false;
	if ( !current_theme_supports( 'lander-auto-updates' ) )
		return false;
	$lander_update = lander_update_check();
	if ( $lander_update ) {
		$value->response['lander'] = $lander_update;
	}
	return $value;
}


function lander_clear_update_transient() {
	delete_transient( 'lander-update' );
}



function lander_update_nag() {
	if ( defined( 'DISALLOW_FILE_MODS' ) && true == DISALLOW_FILE_MODS )
		return false;
	if ( !current_theme_supports( 'lander-auto-updates' ) )
		return false;
	
	$lander_update = lander_update_check();

	if ( ! is_super_admin() || ! $lander_update )
		return false;

	echo '<div id="update-nag">';
	printf(
		__( 'Lander µFrameWork %s is available. <a href="%s" %s>Check out what\'s new</a> or <a href="%s" %s>update now.</a>', CHILD_DOMAIN ),
			esc_html( $lander_update['new_version'] ),
			//esc_url( $lander_update['changelog_url'] ),
			esc_url( 'https://binaryturf.com/lander-changelog' ),
			'class="thickbox thickbox-preview"',
			wp_nonce_url( 'update.php?action=upgrade-theme&amp;theme=lander', 'upgrade-theme_lander' ),
			'class="genesis-js-confirm-upgrade"'
	);
	echo '</div>';

}