<?php

function lander_extras_menu() {
	global $lander_extras;
	$lander_extras = new Lander_Extras;
}

class Lander_Extras extends Genesis_Admin_Boxes {
	
	function __construct() {
		$page_id  = CHILD_SETTINGS_FIELD_EXTRAS;
		$menu_ops = array(
			'submenu' => array(
				'parent_slug' => __( 'genesis', CHILD_DOMAIN ),
				'page_title' => __( 'Lander Admin', CHILD_DOMAIN ),
				'menu_title' => __( 'Lander Admin', CHILD_DOMAIN ) 
			) 
		);
		$page_ops = array(
			'screen_icon' => 'themes',
		);
		$settings_field = CHILD_SETTINGS_FIELD_EXTRAS;
		$default_settings = lander_admin_defaults();
		$this->create( $page_id, $menu_ops, $page_ops,$settings_field,$default_settings );
		add_action( 'admin_print_styles', array(
			 $this,
			'styles' 
		) );
	}	
	
	function styles(){
		wp_enqueue_style( 'lander-admin-style', CHILD_URL . '/lib/css/lander-admin.css' );
	}
	
	function help() {
	}
	
	function metaboxes() {
		add_meta_box( 'lander_extras_license', __('License Key',CHILD_DOMAIN), array(
			 $this,
			'lander_license' 
		), $this->pagehook, 'main' );

		add_meta_box( 'lander_extras_design', __('Design Selector',CHILD_DOMAIN), array(
			 $this,
			'customization_settings_box' 
		), $this->pagehook, 'main' );
		
		add_meta_box( 'lander_widget_settings_box', __('Widget Areas',CHILD_DOMAIN), array(
			 $this,
			'widget_settings_box' 
		), $this->pagehook, 'main' );
		
		add_meta_box( 'lander_debug_settings_box', __('Debug Tools',CHILD_DOMAIN), array(
			 $this,
			'debug_settings_box' 
		), $this->pagehook, 'main' );
		
		add_meta_box( 'lander_extras_webmasters', __('Lander Getting Started Guide',CHILD_DOMAIN), array(
			 $this,
			'lander_startup_guide' 
		), $this->pagehook, 'main' );
	}
	
	function save( $newsettings, $oldsettings ) {
		$design_field = isset($newsettings['design'])?$newsettings['design']:'vanilla';		
		$customization = $design_field;
		$all_customizations = lander_customization_aggregator();
		if(is_array( $all_customizations ) && array_key_exists( $design_field, $all_customizations )){
			$current_customization = $all_customizations[ $design_field ];		
			if ( is_array( $current_customization ) && array_key_exists( 'functions', $current_customization ) ) {
				include_once( $current_customization[ 'functions' ] );
			}
		}
		lander_init_css(get_option(CHILD_SETTINGS_FIELD.'-'.$design_field));		
		if(isset($newsettings['new-design']) && !empty($newsettings['new-design'])) {
			$new_design = lander_ws($newsettings['new-design']);			
			if(!empty($new_design)){
				lander_init_path(LANDER_USER_DESIGNS.'/'.$new_design);
				touch(LANDER_USER_DESIGNS.'/'.$new_design.'/functions.php');
				touch(LANDER_USER_DESIGNS.'/'.$new_design.'/style.scss');
				$newsettings['design'] = $new_design;				
			}
		}
		return $newsettings;
	}
	
	function scripts() {
		parent::scripts();
		genesis_load_admin_js();		
		wp_enqueue_script( 'lander-admin-js', CHILD_URL . '/lib/js/lander-admin.js' );		
		wp_localize_script( 'lander-admin-js', CHILD_DOMAIN, array(
			'pageHook'      => $this->pagehook,
			'firstTime'     => ! is_array( get_user_option( 'closedpostboxes_' . $this->pagehook ) ),
			) );
	}
	
	function lander_license(){
	?>
	<p><label for="<?php echo $this->settings_field;?>[license]"><?php _e('Enter your license key here. Without it, no updates!',CHILD_DOMAIN)?></label></p>
	<p><input 
		type="text" 
		id="<?php echo $this->settings_field;?>[license]" 
		name="<?php echo $this->settings_field;?>[license]" 
		value="<?php echo genesis_get_option( 'license',$this->settings_field,false ); ?>" /></p>
	<?php
	}
	
	function customization_settings_box() {
		$lander_customizations = lander_customization_aggregator();
?>
			<div class="gl-section">
			  <div class="gl-desc">
				<table class="gl-col-table">
				  <tr>
					<td colspan="2">
						<p class="l-desc"><label><?php _e('Please select a design to use. The following designs are available.',CHILD_DOMAIN); ?></label></p>
					</td>
				</tr><tr>
					<td class="gl-label"><p>
						<label for="<?php
		echo $this->settings_field . '[design]';
?>"><?php _e('Designs',CHILD_DOMAIN); ?></label>
					  </p></td>
					<td class="lander-input"><p>
						<?php
		if ( is_array( $lander_customizations ) ) {
			echo '<select class="customization" id="' . $this->settings_field . '[design]" name="' . $this->settings_field . '[design]">';
			$current_customization = genesis_get_option( 'design',$this->settings_field,false );
			foreach ( $lander_customizations as $key => $value ) {
				$selected = selected( $current_customization, $key, 0 );
				echo '<option ' . $selected . ' value="' . $key . '">' . $value['name'] . '</option>' . "\n";
			}
			echo '</select>';
		}
		else {
			_e('Currently there are no customizations. But you can create one.',CHILD_DOMAIN);
		}
?>
					  </p></td>					  
				  </tr>
				  <tr><td colspan="2"><p><?php printf(__('Please go to <a href="%s" >Lander Design</a> to set up the initial design.',CHILD_DOMAIN), esc_url(menu_page_url(lander_get_design_page_id(),0))); ?></p><?php
						$current_design = genesis_get_option( 'design',$this->settings_field,false );
						if(is_array( $lander_customizations ) && array_key_exists( $current_design, $lander_customizations ) ) {
							$current_design = $lander_customizations[$current_design];
							if($current_design['type'] != 'core') {
								echo '<p>'.__('Please edit the following file(s) to customize the design further.', CHILD_DOMAIN).'</p>';
								if(array_key_exists('functions',$current_design)){
									echo '<pre>&#9632;&nbsp;'.str_ireplace(ABSPATH,'',$current_design['functions']).'</pre>';
								}
								if(array_key_exists('sass',$current_design)){
									$path = str_ireplace(ABSPATH,'',$current_design['functions']);								
									$path = str_ireplace('functions.php','style.scss',$path);								
									echo '<pre>&#9632;&nbsp;'.$path.'</pre>';
								}								
							}
						}
						?></td></tr>
				  <tr><td class="gl-label"><p class="l-desc"><label><?php _e('Or create a new design',CHILD_DOMAIN); ?></label></p></td><td class="lander-input">
						<p><input class="new-design" type="text" id="<?php
		echo $this->settings_field;
?>[new-design]" name="<?php
		echo $this->settings_field;
?>[new-design]" value="<?php
?>" /></p>
					</td></tr>
				</table>
			  </div>
			</div>
		<?php
	}
	
function widget_settings_box() {
		$cta_position = genesis_get_option( 'cta-position' ,$this->settings_field,false );
?>  
		<div class="gl-section">
		  <div class="gl-desc">
			<table class="gl-cta-table">
				<tr>
				<td class="gl-label">
					<p>
					<label for="<?php
		echo $this->settings_field . '[footer-widgets]';
?>"><?php _e( 'Footer Widgets Support', CHILD_DOMAIN ); ?></label>
					</p>
				</td>
				<td class="lander-input gl-fw-select" colspan="2">
				<?php
				$fwnum = array(
					'enable',
					'disable' 
				);
				
				echo '<select id="' . $this->settings_field . '[footer-widgets]" name="' . $this->settings_field . '[footer-widgets]">';
				$fwn = genesis_get_option( 'footer-widgets' ,$this->settings_field, false );
				foreach ( $fwnum as $wnum ) {
					echo "<option " . selected( $wnum, $fwn, false ) . " value=\"$wnum\">" . ucwords( $wnum ) . "</option>\n";
				} //$fwnum as $wnum
				echo '</select>';
				
				$fwidgets_count = array(
					'1',
					'2',
					'3',
					'4'
				);
?>
		
				<div id="fwidget-count">
					<?php
					echo '<select id="' . $this->settings_field . '[footer-widgets-count]" name="' . $this->settings_field . '[footer-widgets-count]">';
					$wcount = genesis_get_option( 'footer-widgets-count', $this->settings_field, false );
					foreach ( $fwidgets_count as $fwidget_count ) {
						echo "<option " . selected( $fwidget_count, $wcount, false ) . " value=\"$fwidget_count\">" . ucwords( $fwidget_count ) . "</option>\n";
						}
					echo '</select>';
					?>
				</div>
				</td>
				
				<tr>
					<td class="gl-label">
						<p><?php _e('Widgets Above Header',CHILD_DOMAIN); ?></p>
					</td>
					<td class="lander-input" colspan="2">
						<p>						
							<?php if ( 'page' === get_option( 'show_on_front' ) ) { ?>
								<label for="<?php echo $this->get_field_id('widgets_before_header_front')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_before_header_front' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_before_header_front' ); ?>" id="<?php echo $this->get_field_id( 'widgets_before_header_front' ); ?>" /><?php _e( 'Front Page', CHILD_DOMAIN ); ?></label>				
								<label for="<?php echo $this->get_field_id('widgets_before_header_posts_page')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_before_header_posts_page' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_before_header_posts_page' ); ?>" id="<?php echo $this->get_field_id( 'widgets_before_header_posts_page' ); ?>" /><?php _e( 'Posts Page', CHILD_DOMAIN ); ?></label>										
							<?php }
							else {
							?>
								<label for="<?php echo $this->get_field_id('widgets_before_header_home')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_before_header_home' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_before_header_home' ); ?>" id="<?php echo $this->get_field_id( 'widgets_before_header_home' ); ?>" /><?php _e( 'Home Page', CHILD_DOMAIN ); ?></label>
							<?php } ?>
						<label for="<?php echo $this->get_field_id('widgets_before_header_post')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_before_header_post' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_before_header_post' ); ?>" id="<?php echo $this->get_field_id( 'widgets_before_header_post' ); ?>" /><?php _e( 'Post', CHILD_DOMAIN ); ?></label>
						<label for="<?php echo $this->get_field_id('widgets_before_header_page')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_before_header_page' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_before_header_page' ); ?>" id="<?php echo $this->get_field_id( 'widgets_before_header_page' ); ?>" /><?php _e( 'Page', CHILD_DOMAIN ); ?></label>
						<label for="<?php echo $this->get_field_id('widgets_before_header_archives')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_before_header_archives' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_before_header_archives' ); ?>" id="<?php echo $this->get_field_id( 'widgets_before_header_archives' ); ?>" /><?php _e( 'Archives', CHILD_DOMAIN ); ?></label>
						<label for="<?php echo $this->get_field_id('widgets_before_header_404')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_before_header_404' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_before_header_404' ); ?>" id="<?php echo $this->get_field_id( 'widgets_before_header_404' ); ?>" /><?php _e( '404', CHILD_DOMAIN ); ?></label>
						</p>
					</td>					  
				</tr>
				<tr>
					<td class="gl-label">
						<p><?php _e('Widgets Below Header',CHILD_DOMAIN);?></p>
					</td>
					<td class="lander-input" colspan="2">
						<p>						
							<?php if ( 'page' === get_option( 'show_on_front' ) ) { ?>
								<label for="<?php echo $this->get_field_id('widgets_after_header_front')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_after_header_front' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_after_header_front' ); ?>" id="<?php echo $this->get_field_id( 'widgets_after_header_front' ); ?>" /><?php _e( 'Front Page', CHILD_DOMAIN ); ?></label>				
								<label for="<?php echo $this->get_field_id('widgets_after_header_posts_page')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_after_header_posts_page' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_after_header_posts_page' ); ?>" id="<?php echo $this->get_field_id( 'widgets_after_header_posts_page' ); ?>" /><?php _e( 'Posts Page', CHILD_DOMAIN ); ?></label>										
							<?php }
							else {
							?>
								<label for="<?php echo $this->get_field_id('widgets_after_header_home')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_after_header_home' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_after_header_home' ); ?>" id="<?php echo $this->get_field_id( 'widgets_after_header_home' ); ?>" /><?php _e( 'Home Page', CHILD_DOMAIN ); ?></label>
							<?php } ?>
						<label for="<?php echo $this->get_field_id('widgets_after_header_post')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_after_header_post' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_after_header_post' ); ?>" id="<?php echo $this->get_field_id( 'widgets_after_header_post' ); ?>" /><?php _e( 'Post', CHILD_DOMAIN ); ?></label>
						<label for="<?php echo $this->get_field_id('widgets_after_header_page')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_after_header_page' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_after_header_page' ); ?>" id="<?php echo $this->get_field_id( 'widgets_after_header_page' ); ?>" /><?php _e( 'Page', CHILD_DOMAIN ); ?></label>
						<label for="<?php echo $this->get_field_id('widgets_after_header_archives')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_after_header_archives' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_after_header_archives' ); ?>" id="<?php echo $this->get_field_id( 'widgets_after_header_archives' ); ?>" /><?php _e( 'Archives', CHILD_DOMAIN ); ?></label>
						<label for="<?php echo $this->get_field_id('widgets_after_header_404')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_after_header_404' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_after_header_404' ); ?>" id="<?php echo $this->get_field_id( 'widgets_after_header_404' ); ?>" /><?php _e( '404', CHILD_DOMAIN ); ?></label>
						</p>
					</td>					  
				</tr>
				
				<tr>
					<td class="gl-label">
						<p><?php _e('Widgets Content Column Top',CHILD_DOMAIN); ?></p>
					</td>
					<td class="lander-input" colspan="2">
						<p>						
							<?php if ( 'page' === get_option( 'show_on_front' ) ) { ?>
								<label for="<?php echo $this->get_field_id('widgets_content_top_front')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_content_top_front' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_content_top_front' ); ?>" id="<?php echo $this->get_field_id( 'widgets_content_top_front' ); ?>" /><?php _e( 'Front Page', CHILD_DOMAIN ); ?></label>				
								<label for="<?php echo $this->get_field_id('widgets_content_top_posts_page')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_content_top_posts_page' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_content_top_posts_page' ); ?>" id="<?php echo $this->get_field_id( 'widgets_content_top_posts_page' ); ?>" /><?php _e( 'Posts Page', CHILD_DOMAIN ); ?></label>										
							<?php }
							else {
							?>
								<label for="<?php echo $this->get_field_id('widgets_content_top_home')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_content_top_home' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_content_top_home' ); ?>" id="<?php echo $this->get_field_id( 'widgets_content_top_home' ); ?>" /><?php _e( 'Home Page', CHILD_DOMAIN ); ?></label>
							<?php } ?>
						<label for="<?php echo $this->get_field_id('widgets_content_top_post')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_content_top_post' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_content_top_post' ); ?>" id="<?php echo $this->get_field_id( 'widgets_content_top_post' ); ?>" /><?php _e( 'Post', CHILD_DOMAIN ); ?></label>
						<label for="<?php echo $this->get_field_id('widgets_content_top_page')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_content_top_page' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_content_top_page' ); ?>" id="<?php echo $this->get_field_id( 'widgets_content_top_page' ); ?>" /><?php _e( 'Page', CHILD_DOMAIN ); ?></label>
						<label for="<?php echo $this->get_field_id('widgets_content_top_archives')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_content_top_archives' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_content_top_archives' ); ?>" id="<?php echo $this->get_field_id( 'widgets_content_top_archives' ); ?>" /><?php _e( 'Archives', CHILD_DOMAIN ); ?></label>
						<label for="<?php echo $this->get_field_id('widgets_content_top_404')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_content_top_404' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_content_top_404' ); ?>" id="<?php echo $this->get_field_id( 'widgets_content_top_404' ); ?>" /><?php _e( '404', CHILD_DOMAIN ); ?></label>
						</p>
					</td>					  
				</tr>
				
				<tr>
					<td class="gl-label">
						<p><?php _e('Widgets Above Footer',CHILD_DOMAIN);?></p>
					</td>
					<td class="lander-input" colspan="2">
						<p>						
							<?php if ( 'page' === get_option( 'show_on_front' ) ) { ?>
								<label for="<?php echo $this->get_field_id('widgets_above_footer_front')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_above_footer_front' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_above_footer_front' ); ?>" id="<?php echo $this->get_field_id( 'widgets_above_footer_front' ); ?>" /><?php _e( 'Front Page', CHILD_DOMAIN ); ?></label>				
								<label for="<?php echo $this->get_field_id('widgets_above_footer_posts_page')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_above_footer_posts_page' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_above_footer_posts_page' ); ?>" id="<?php echo $this->get_field_id( 'widgets_above_footer_posts_page' ); ?>" /><?php _e( 'Posts Page', CHILD_DOMAIN ); ?></label>										
							<?php }
							else {
							?>
								<label for="<?php echo $this->get_field_id('widgets_above_footer_home')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_above_footer_home' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_above_footer_home' ); ?>" id="<?php echo $this->get_field_id( 'widgets_above_footer_home' ); ?>" /><?php _e( 'Home Page', CHILD_DOMAIN ); ?></label>
							<?php } ?>
						<label for="<?php echo $this->get_field_id('widgets_above_footer_post')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_above_footer_post' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_above_footer_post' ); ?>" id="<?php echo $this->get_field_id( 'widgets_above_footer_post' ); ?>" /><?php _e( 'Post', CHILD_DOMAIN ); ?></label>
						<label for="<?php echo $this->get_field_id('widgets_above_footer_page')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_above_footer_page' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_above_footer_page' ); ?>" id="<?php echo $this->get_field_id( 'widgets_above_footer_page' ); ?>" /><?php _e( 'Page', CHILD_DOMAIN ); ?></label>
						<label for="<?php echo $this->get_field_id('widgets_above_footer_archives')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_above_footer_archives' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_above_footer_archives' ); ?>" id="<?php echo $this->get_field_id( 'widgets_above_footer_archives' ); ?>" /><?php _e( 'Archives', CHILD_DOMAIN ); ?></label>
						<label for="<?php echo $this->get_field_id('widgets_above_footer_404')?>"><input value="1"<?php checked( $this->get_field_value( 'widgets_above_footer_404' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'widgets_above_footer_404' ); ?>" id="<?php echo $this->get_field_id( 'widgets_above_footer_404' ); ?>" /><?php _e( '404', CHILD_DOMAIN ); ?></label>
						</p>
					</td>					  
				</tr>
				 
				<tr <?php if ( 'page' !== get_option( 'show_on_front' ) ) {echo 'style="display:none"';} ?>>
					<td class="gl-label" colspan="2">						
						<p>
						<label for="<?php echo $this->get_field_id('hide_loop_on_front')?>"><input value="1"<?php checked( $this->get_field_value( 'hide_loop_on_front' ) ); ?> type="checkbox" name="<?php echo $this->get_field_name( 'hide_loop_on_front' ); ?>" id="<?php echo $this->get_field_id( 'hide_loop_on_front' ); ?>" /><?php _e( 'Hide Page Content On Front Page', CHILD_DOMAIN ); ?></label>
						</p>
					</td>
				</tr>
				 			 
			</table>
		  </div>
		</div>
		<?php
	}
	
function debug_settings_box() {
	?>
			<div class="gl-section">
			  <div class="gl-desc">
				<table class="gl-col-table">
					<tr>
						<td>
							<p class="l-desc"><?php _e('For troubleshooting and debugging purposes, you can enable or disable certain customizations from right here.',CHILD_DOMAIN);?></p>
						</td>
					</tr>
					<tr>
						<td class="gl-label">
							<p>
							<label for="<?php
		echo $this->settings_field . '[custom-functions-enabled]';
?>"><input id="<?php
		echo $this->settings_field . '[custom-functions-enabled]';
?>" name="<?php
		echo $this->settings_field . '[custom-functions-enabled]';
?>"  type="checkbox" value='1' <?php
		checked( genesis_get_option( 'custom-functions-enabled' ,$this->settings_field,false ), '1' );
?> /><?php _e('Enable <code>functions.php</code> [user functions stored in functions.php]',CHILD_DOMAIN);?></label>
							</p>
						</td>
					</tr>
					<tr>
						<td class="gl-label">
							<p>
							<label for="<?php
		echo $this->settings_field . '[custom-style-enabled]';
?>"><input id="<?php
		echo $this->settings_field . '[custom-style-enabled]';
?>" name="<?php
		echo $this->settings_field . '[custom-style-enabled]';
?>" type="checkbox" value='1' <?php
		checked( genesis_get_option( 'custom-style-enabled' ,$this->settings_field,false ), '1' );
?> /><?php _e('Enable <code>style.scss</code> [user styles stored in style.scss]',CHILD_DOMAIN);?></label>
							</p>
						</td>
					</tr>
				</table>
			  </div>
			</div>
		<?php
	}
	function lander_startup_guide(){
	?><h4 class="guide_head"><?php _e('Webmasters Checklist', CHILD_DOMAIN);?></h4>
		<p><?php _e('Here\'s a small checklist to help you make sure that your site is ready to flaunt the Lander awesomeness: (So that we don\'t lose you, all links open in new pages.)', CHILD_DOMAIN);?></p>
		<ol>		
		<li><?php _e('Make sure you are not using the WordPress default tagline "Just another WordPress blog". It will affect your meta description.', CHILD_DOMAIN);?></li>		
		<li><?php printf(__('Visit <a target="_blank" href="%s">Genesis SEO settings</a> and ensure that you have a homepage document title and meta description set.', CHILD_DOMAIN),menu_page_url( 'seo-settings', false ));?></li>		
		<li><?php _e('Enable Google Authorship and/or Publisher markup and verify at Google\'s <a target="_blank" href="http://www.google.com/webmasters/tools/richsnippets">Structured Data Testing Tool</a>.', CHILD_DOMAIN);?></li>		
		<li><?php printf(__('How does your 404 Page look? Visit <a target="_blank" href="%s">this page</a> (<em>Recommended</em>).', CHILD_DOMAIN), get_home_url() . '/?p=' . time());?></li>		
		<li><?php printf(__('Enable pretty <a target="_blank" href="%s">permalinks</a> under permalink settings.', CHILD_DOMAIN), get_admin_url() . 'options-permalink.php');?></li>		
		<li><?php printf(__('Setup and integrate <a target="_blank" href="http://www.google.com/analytics/">Google Analytics</a>. Place the code under <a target="_blank" href="%s">Genesis Theme Settings</a> into the header scripts (wp_head) box.', CHILD_DOMAIN), menu_page_url( 'genesis', false ));?></li>		
		<li><?php _e('Verify your site at <a target="_blank" href="http://www.google.com/webmasters/">Google Webmasters</a> and <a target="_blank" href="http://www.bing.com/toolbox/webmaster">Bing Webmasters</a> setup. Also submit your xml sitemap (if you have one).', CHILD_DOMAIN);?></li>		
		<li><?php printf(__('If your website doesn’t have a favicon yet, you can <a target="_blank" href="%s">set one here</a>.', CHILD_DOMAIN), menu_page_url( CHILD_SETTINGS_FIELD_BRANDING, false ));?></li>		
		<li><?php printf(__('Uncheck Discourage search engines from indexing this site option under <a target="_blank" href="%s">reading settings</a> so that search bots can index your site.', CHILD_DOMAIN), get_admin_url() . 'options-reading.php');?></li>
		</ol>		
		<p><?php _e('Optionally&hellip;', CHILD_DOMAIN);?></p>		
		<ul>
			<li><?php _e('Setup RSS feed / Feedburner / Aweber / Mailchimp.', CHILD_DOMAIN);?></li>		
		</ul>
	<h4 class="guide_head"><?php _e('Creating Landing Page Experiences', CHILD_DOMAIN);?></h4>
	<p><strong><?php _e('Lander doesn\'t come with any Landing Template. That\'s because Lander allows you to turn any post or page into a landing page. Here\'s how to use it.', CHILD_DOMAIN);?></strong></p>
	<ol>
	<li><?php _e('Open up any page or post in the edit screen inside the admin area. Now you\'ll see additional options on the side wherein you can toggle on/off certain elements in the page layout.', CHILD_DOMAIN);?></li>	
	<li><?php _e('Also you can select the page layout via Genesis <strong>Layout Settings</strong> metabox below the edit screen.', CHILD_DOMAIN);?></li>
	</ol>
	<h4 class="guide_head"><?php _e('Lander Hooks Reference', CHILD_DOMAIN);?></h4>
		<p><strong><?php _e('Lander has some divine powers. But worry not, for they follow WordPress and Genesis coding standards. Let\'s get started.', CHILD_DOMAIN);?></strong></p>		
		<p><?php _e('<strong>Note: </strong>For an updated reference, please visit the on-line help.', CHILD_DOMAIN);?></p>
		<p><strong><?php _e('Action Hooks &lt;include parameters&gt;', CHILD_DOMAIN);?></strong></p>
		<dl>
			<dt>lander_before_landing_page_loop</dt><dd><?php _e('Needs Replacement.', CHILD_DOMAIN);?></dd>
			<dt>lander_after_landing_page_loop</dt><dd><?php _e('Needs Replacement.', CHILD_DOMAIN);?></dd>
			<dt>lander_design_before_metaboxes</dt><dd><?php _e('Some text.', CHILD_DOMAIN);?></dd>
			<dt>lander_design_after_metaboxes</dt><dd><?php _e('Some text.', CHILD_DOMAIN);?></dd>
			<dt>lander_favicon_form</dt><dd><?php _e('Some text.', CHILD_DOMAIN);?></dd>
		</dl>		
		<p><strong><?php _e('Filter Hooks &lt;include parameters&gt;', CHILD_DOMAIN);?></strong></p>
		<dl>
			<dt>lander_attrib</dt><dd><?php _e('Some text.', CHILD_DOMAIN);?></dd>
			<dt>landing_section</dt><dd><?php _e('Some text.', CHILD_DOMAIN);?></dd>
			<dt>lander_settings</dt><dd><?php _e('Some text.', CHILD_DOMAIN);?></dd>
			<dt>lander_clean_css</dt><dd><?php _e('Some text.', CHILD_DOMAIN);?></dd>
			<dt>lander_design_defaults</dt><dd><?php _e('Some text.', CHILD_DOMAIN);?></dd>
			<dt>lander_screenshot_types</dt><dd><?php _e('Some text.', CHILD_DOMAIN);?></dd>
			<dt>lander_favicon_types</dt><dd><?php _e('Some text.', CHILD_DOMAIN);?></dd>
			<dt>lander_fonts</dt><dd><?php _e('Some text.', CHILD_DOMAIN);?></dd>
			<dt>lander_schemas</dt><dd><?php _e('Some text.', CHILD_DOMAIN);?></dd>
		</dl>
	<h4 class="guide_head"><?php _e('Customizing Lander', CHILD_DOMAIN);?></h4>
		<p><?php _e('Lander\'s killer feature is the ability to save and switch amongst your designs. However before we get to that, let\'s understand how you can tweak and tame Lander.', CHILD_DOMAIN);?></p>
		<p><?php printf(__('Primarily you can place all your custom functions in <code>%s</code>. Treat this as a master functions file that will affect all designs.', CHILD_DOMAIN), lander_get_res( 'file', 'userphp' ));?></p>
		<p><?php printf(__('You can place all your custom styles in <code>%s</code>. Treat this as a master stylesheet that will affect all designs.', CHILD_DOMAIN), lander_get_res( 'file', 'usercss' ));?></p>
		<p><?php _e('<strong>Note: </strong>These above-said files are enqueued after the designs, thus any code in above files will override the designs if you have selected one.', CHILD_DOMAIN);?></p>
		<p><?php _e('Now let\'s say you\'ve customized the above-said <code>functions.php</code> and <code>style.css</code> to your heart\'s satisfaction. But that\'s not the end of story. Lander allows you to save these designs into a folder so that you can create multiple, new designs and switch between them. And this is the beauty of Lander &mdash; <strong>you never need to use another child-theme!</strong> :)', CHILD_DOMAIN);?></p>
		<p><strong><?php _e('Here are the steps involved in creating a design.', CHILD_DOMAIN);?></strong></p>
		<ol>
			<li><?php printf(__('Create a folder inside <code>%s</code>. Let\'s name it <strong>photo-look</strong> (it\'s highly recommended that you keep it all lowercase with the words separated by a dash (<code>-</code>) character).', CHILD_DOMAIN), LANDER_USER_DESIGNS.'/');?></li>
			<li><?php _e('Place at least functions.php or style.css file inside the <code>photo-look</code> folder. This will make sure that Lander recognizes it as a valid design.', CHILD_DOMAIN);?></li>
			<li><?php printf(__('Now when you visit <a target="_blank" href="%s" />Theme design Selector</a>, you\'ll see your design appear as <code>Photo Look</code>.', CHILD_DOMAIN), menu_page_url( CHILD_THEME_NAME_WS . '-settings', 0 ).'#lander_extras_design');?> </li>
			<li><?php _e('You can select this from the dropdown and save it. This will activate the <code>Photo Look</code> design and put it into effect.', CHILD_DOMAIN);?></li>
		</ol>
		
		<p><?php _e('You can also set some default settings for each design that you create. Just do the following:', CHILD_DOMAIN);?></p>

<ol>
<li><?php _e('Head on to Genesis Import/Export screen.', CHILD_DOMAIN);?></li>
<li><?php _e('<strong>Check Lander Settings</strong> and download the export file.', CHILD_DOMAIN);?></li>
<li><?php _e('Rename this file to defaults.json.', CHILD_DOMAIN);?></li>
<li><?php _e('Upload this file using ftp and place it inside your design folder. Eg. in the above case, upload it inside the photo-look folder. Thus the location will be <code>wp-content/uploads/lander-user/designs/photo-look/defaults.json</code>', CHILD_DOMAIN);?></li>
<li><?php _e('Next time you switch to the <strong>Photo Look</strong> design, these settings will be populated automatically.', CHILD_DOMAIN);?></li>
</ol>
		<p><?php _e('Similarly you can create other designs and switch between them. If you are a designer you can just develop new ones for your customers!', CHILD_DOMAIN);?></p>
		<?php
	}
}
