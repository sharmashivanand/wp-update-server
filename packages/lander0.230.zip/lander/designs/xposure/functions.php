<?php

/* Theme customizations for xposure — classic artistic Lander μFrameWork design*/

add_action ('wp_head','xposure_font_scripts');

function xposure_font_scripts(){
	echo '<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,600,600italic,700italic,700,400italic,300,300italic|Merriweather:400,300,300italic,400italic,700,700italic" rel="stylesheet" type="text/css" />';
}

add_filter('lander_fonts','xposure_fonts');

function xposure_fonts($fonts){
	$fonts['open_sans'] = array(
		 'name' => 'Open Sans',
		'family' => '"Open Sans", "Helvetica Neue", Helvetica, sans-serif',
		'web_safe' => true,
		'google' => true,
		'monospace' => false 
	);
	$fonts['merriweather'] = array(
		 'name' => 'Merriweather',
		'family' => '"Merriweather", "Times New Roman", serif',
		'web_safe' => true,
		'google' => true,
		'monospace' => false 
	);
	return $fonts;
}

add_filter('lander_settings_css','xposure_css',10,3);

function xposure_css ($css,$settings,$widths) {
	return $css;
}

add_filter('lander_media_queries','xposure_resp_css',10,3);

function xposure_resp_css($resp_css, $widths, $settings) {
	return $resp_css; 

}

add_filter('lander_design_defaults','xposure_defaults');

function xposure_defaults($defaults){
	$defaults['layout']='fullwidth';
	$defaults['col-spacing']=100;
	$defaults['column-content-1col']=760;
	$defaults['column-content-2col']=460;
	$defaults['sidebar-one-2col']=200;
	$defaults['column-content-3col']=320;
	$defaults['sidebar-one-3col']=120;
	$defaults['sidebar-two-3col']=120;
	$defaults['body-font-family']='helvetica';
	$defaults['content-area-font-size']=14;
	$defaults['content-area-font-weight']='normal';
	$defaults['site-background-color']='#eee';
	$defaults['page-background-color']='transparent';
	$defaults['primary-text-color']='#111111';
	$defaults['primary-link-color']='#2361A1';
	$defaults['primary-link-hover-color']='#2361A1';
	$defaults['header-area-font-color']='#555';
	$defaults['header-area-font-size']=48;
	$defaults['header-area-font-weight']='normal';
	$defaults['header-area-font-family']='times_new_roman';
	$defaults['header-area-tagline-font-color']='#888888';
	$defaults['header-area-tagline-font-size']=14;
	$defaults['header-area-tagline-font-weight']='normal';
	$defaults['header-area-tagline-font-family']='_inherit';
	$defaults['headline-font-color']='#111111';
	$defaults['headline-font-weight']='normal';
	$defaults['headline-font-size']=24;
	$defaults['headline-font-family']='times_new_roman';
	$defaults['headline-subhead-font-color']='#111111';
	$defaults['headline-subhead-font-weight']='normal';
	$defaults['headline-subhead-font-family']='_inherit';
	$defaults['nav-menu-font-family']='_inherit';
	$defaults['nav-menu-font-size']=13;
	$defaults['nav-menu-font-weight']='normal';
	$defaults['nav-menu-link-text-color']='#666';
	$defaults['nav-menu-link-text-hover-color']='#ff7256';
	$defaults['nav-menu-current-link-text-color']='#ff7256';
	$defaults['nav-menu-current-parent-link-text-color']='#ff7256';
	$defaults['nav-menu-link-bg-color']='transparent';
	$defaults['nav-menu-hover-bg-color']='transparent';
	$defaults['nav-menu-current-bg-color']='transparent';
	$defaults['nav-menu-current-parent-bg-color']='transparent';
	$defaults['nav-menu-border-width']=0;
	$defaults['nav-menu-border-color']='#ddd';
	$defaults['nav-menu-submenu-width']=200;
	$defaults['subnav-menu-font-family']='_inherit';
	$defaults['subnav-menu-font-size']=12;
	$defaults['subnav-menu-font-weight']='normal';
	$defaults['subnav-menu-link-text-color']='#666';
	$defaults['subnav-menu-link-text-hover-color']='#ff7256';
	$defaults['subnav-menu-current-link-text-color']='#ff7256';
	$defaults['subnav-menu-current-parent-link-text-color']='#ff7256';
	$defaults['subnav-menu-link-bg-color']='#fff';
	$defaults['subnav-menu-hover-bg-color']='#fff';
	$defaults['subnav-menu-current-bg-color']='#ffffff';
	$defaults['subnav-menu-current-parent-bg-color']='#fff';
	$defaults['subnav-menu-border-width']=0;
	$defaults['subnav-menu-border-color']='#ddd';
	$defaults['subnav-menu-submenu-width']=200;
	$defaults['byline-font-family']='_inherit';
	$defaults['byline-font-color']='#888888';
	$defaults['byline-font-size']=12;
	$defaults['code-font-color']='#111111';
	$defaults['code-font-size']=12;
	$defaults['code-font-family']='consolas';
	$defaults['sidebar-font-family']='_inherit';
	$defaults['sidebar-font-color']='#111111';
	$defaults['sidebar-font-size']=13;
	$defaults['sidebar-font-weight']='normal';
	$defaults['sidebar-heading-font-family']='times_new_roman';
	$defaults['sidebar-heading-font-size']=13;
	$defaults['sidebar-heading-font-weight']='normal';
	$defaults['sidebar-heading-font-color']='#555555';
	$defaults['footer-widgets']='enable';
	$defaults['footer-widgets-font-family']='_inherit';
	$defaults['footer-widgets-font-color']='#fff';
	$defaults['footer-widgets-font-size']=13;
	$defaults['footer-widgets-font-weight']='normal';
	$defaults['footer-widgets-heading-font-family']='arial';
	$defaults['footer-widgets-heading-font-size']=15;
	$defaults['footer-widgets-heading-font-weight']='bold';
	$defaults['footer-widgets-heading-font-color']='#fff';
	$defaults['footer-font-family']='_inherit';
	$defaults['footer-font-color']='#555';
	$defaults['footer-font-size']=12;
	$defaults['footer-font-weight']='normal';
	return $defaults;
}