=== Lander µFrameWork ===
Contributors: varun21, aniash_29, ruchika_wp
Tags: clean
Requires at least: 3.6
Tested up to: 4.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Lander µFrameWork for Genesis puts Genesis on steroids and gives you the reins to control Genesis in your hands.

== Description ==

Lander µFrameWork for Genesis puts Genesis on steroids and gives you the reins to control Genesis in your hands.

= Using Lander µFrameWork =

Just install as usual and follow the steps.

= Lander µFrameWork allows you to: =

1. Rock the boats out of WordPress

= Also read: =

1. https://www.binaryturf.com/genesis-developer

== Installation ==

Just install as usual and follow the steps.

== Screenshots ==

1. None

== Frequently Asked Questions ==

= How do I start using Lander µFrameWork? =

1. Pretty easy

== Changelog ==

= 1.0 =
This is the initial release of the theme.