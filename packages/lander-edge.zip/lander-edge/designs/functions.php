<?php
/******** Place all your wp/php tweaks here ****************/
/******** This is your theme's master functions.php file ******/

