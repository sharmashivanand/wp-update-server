<?php

add_action( 'admin_init', 'lander_add_tax_menu_settings_box' );

function lander_add_tax_menu_settings_box() {
	$taxonomies = array( 'category' );
	$tax_names = apply_filters('lander_tax_custom_menu_locations', $taxonomies);
	$all_tax = get_taxonomies( array( 'public' => true ) );
	foreach ($tax_names as $tax_name) {
		if( in_array( $tax_name, $all_tax ) ) {
			add_action( $tax_name . '_edit_form', 'lander_tax_menu_meta_box', 10, 2 );
		}
	}
}

function lander_tax_menu_meta_box( $tag, $taxonomy ) {
	$tax = get_taxonomy( $taxonomy );
	$term_meta = (array) get_option( 'lander-tax-meta' );
	$selected = false;
	$locations = get_registered_nav_menus(); //Returns an array of all registered navigation menus in a theme (locations)
    $assigned_menus = get_nav_menu_locations(); //Returns an array with the registered navigation menu locations + the menu assigned to it
    $all_menus = wp_get_nav_menus(); //Returns all navigation menu objects
	//insert additional options as fake menu options
	array_unshift($all_menus,(object)array('name'=>'&mdash;Theme Default&mdash;','term_id' => '-2'),(object)array('name'=>'&mdash;None&mdash;','term_id' => '-1'));
	
	?>
	<h3><?php echo esc_html( $tax->labels->singular_name ) . ' ' . __( 'Custom Menu Settings', 'CHILD_DOMAIN' ); ?></h3>
	<?php
	echo '<p>' . sprintf( 'Select which custom menu appears in each location for this %s.', strtolower ($tax->labels->singular_name) ) . '</p>';
	?>
	<table class="widefat fixed" id="menu-locations-table">
		<thead>
		<tr>
			<th scope="col" class="manage-column column-locations"><?php _e( 'Theme Location' ); ?></th>
			<th scope="col" class="manage-column column-menus"><?php _e( 'Assigned Menu' ); ?></th>
		</tr>
		</thead>
		<?php
		?>
		<tbody class="menu-locations">
		   <tr>
				<td colspan = "2">
					<p><?php echo sprintf( '<em>Only the menu locations for which the menus have been assigned on <a href="%s">Menus</a> screen will appear here.</em>', admin_url('nav-menus.php') ); ?></p>
				</td>
		   </tr>
		   <?php
		    foreach($locations as $loc_slug => $loc_name) {
				if(!has_nav_menu( $loc_slug )) continue;
				?>
				   <tr>
						<td class="menu-location-title"><label for = "lander-tax-meta[<?php echo $loc_slug; ?>]"><strong><?php echo $loc_name; ?></strong></label></td>
						<td class="menu-location-menus">
							<select name="lander-tax-meta[<?php echo $loc_slug; ?>]" id="lander-tax-meta[<?php echo $loc_slug; ?>]">
								<?php 
								foreach ( $all_menus as $menu ) { ?>
								<?php if(isset ($term_meta[$tag->term_id])) {
									$selected = $term_meta[$tag->term_id][$loc_slug] == $menu->term_id ;
								} ?>
								<option <?php if ( $selected ) echo 'data-orig="true"'; ?> <?php selected( $selected ); ?> value="<?php echo $menu->term_id; ?>">
								<?php echo wp_html_excerpt( $menu->name, 40, '&hellip;' ); ?>
								</option>
								<?php 
								}
								?>
							 </select>
						</td>
					</tr>
				<?php
			}
	   ?>
		</tbody>
   </table>
   <?php
}

add_action( 'edited_term', 'lander_save_term_meta', 10, 3 );

function lander_save_term_meta( $term_id, $tt_id, $taxonomy  ) {
	if ( defined( 'DOING_AJAX' ) && DOING_AJAX )
		return;
	
	$term_meta = (array) get_option( 'lander-tax-meta' );

	$term_meta[$term_id] = isset( $_POST['lander-tax-meta'] ) ? $_POST['lander-tax-meta'] : array();
	
	/* OK, it's safe for us to save the data now. */
    // Make sure that it is set.
	
	$lander_tax_custom_menus = array();
   
	$locations = $_POST['lander-tax-meta'];
	foreach($locations as $loc => $menu_id) {
		$lander_tax_custom_menus[$loc] = $menu_id;
	}
	
	// Save the option array.
	update_option( 'lander-tax-meta', $term_meta );

}

/* Checks if custom menu is set
 * If custom menu is set, modify the wp_nav_menu_args
 * And assign selected menu to the defined theme locations
 */

add_filter( 'wp_nav_menu_args', 'lander_get_tax_menus' );

function lander_get_tax_menus($args){  
	if ( ! is_category() && ! is_tag() && ! is_tax() ) {
		return $args;
	}
	$lander_tax_menus = get_option( 'lander-tax-meta' );
	$lander_tax_menus = maybe_unserialize( $lander_tax_menus ) ;
	if($lander_tax_menus) {
		foreach($lander_tax_menus as $term_id => $menu_locations) {
			if(is_category( $term_id ) || is_tag( $term_id ) || is_tax( $term_id )) {
				foreach($menu_locations as $menu_location => $menu_id) {
					if($args['theme_location'] == $menu_location) { //if 
						if($menu_id != '-2') { //if something custom is set
							$args['menu'] = $menu_id;
							$args['fallback_cb'] = -1;
							$args['theme_location'] = -1;
						}
					}
				}
			}
		}
	}
	return $args;
}