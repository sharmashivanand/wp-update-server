<?php
if ( !defined( 'SORT_NATURAL' ) ) {
	define( 'SORT_NATURAL', 5 );
}

function lander_font_weights($font_id){
	//return array('normal','bold','bolder','lighter','100','200','300','400','500','600','700','800','900');	
	if($font_id){
		$font_specs = lander_get_font($font_id);
		return $font_specs['font_weights'];
	}
	else {
		return array('normal','bold');	
		}
}



//returns the font-family for a given font
function lander_fontfamily( $value = 'inherit' ) {
	$font_faces = lander_get_fonts();
	if ( $value == 'inherit' || empty( $value ) ) {
		return 'inherit';
	}
	return $font_faces[$value]['family'];
}

function enqueue_web_fonts(){
//get all active fonts?
	
	//build an array of font settings from the entire design settings
	$fonts = get_option(lander_get_design_page_id());	//get all settings
	$fonts = lander_get_settings_fonts($fonts);	//filter the ones with font-families

	
	$lander_all_fonts = lander_get_fonts();	//get all fonts
	$font_families = array();
	
	//push all font-families in the current settings into an array
	foreach($fonts as $key => $value){
		$font_families[$value] = $lander_all_fonts[$value];
	}
	
	
	//build the script src.
	$font_src = array(); 
	foreach($font_families as $key => $value){
		if($value['google']){
			$font_src[] = $value['name'];
		}
	}
	if(!count($font_src)) {
		return;
	}
	$font_src = implode('|',$font_src);
	wp_enqueue_style( 'lander_web_fonts', 'http://fonts.googleapis.com/css?family='.urlencode($font_src),array() , null, 'all');
}

function lander_get_settings_fonts($settings){
	$font_settings = array();
	foreach($settings as $key => $value) {
		if (preg_match('/font\-family/',$key)){
			$font_settings[$key] = $value;
		}
	}
	return $font_settings;
}

//add_action( 'wp_enqueue_scripts', 'enqueue_Web_fonts' );

/***************************************************************************
************************ New super font functions **************************
***************************************************************************/


/*
 returns the font weight from a font variant string
 $variant: font variant in google format (700italic, 700, italic)
*/
function lander_get_font_weight($variant){
	$weight = intval($variant, 10);
	if(!$weight || stristr($variant,'regular')) {
		$weight = '400';
	}
	return $weight;
}

/*
 returns the font style from a font variant string
 $variant: font variant in google format (700italic, 700, italic)
*/
function lander_get_font_style($variant){
	$style="normal";
	if($variant == 'italic' || stristr($variant,'italic')) {
		$style = 'italic';
	}
	return $style;
}

/*
 returns a particular font as an array including it's specs from the entire list of fonts.
 $variant: font variant in google format (700italic, 700, italic)
*/
function lander_get_font($font){
	$all_fonts = lander_get_super_fonts();
	$font = $all_fonts[$font];
	return $font;
}

/*
 returns the fallback font-family for a particular font
 $font_id: the font as the key in the fonts list.
*/
function lander_get_font_family($font_id){
	$font = lander_get_font($font_id);
	$font_family = $font['name'];

	if($font_family == 'inherit')
			return 'inherit';

	$font_family = '"'.$font_family.'"';
//llog($font);
	if($font['category'] == 'handwriting' || $font['category'] == 'display') {
		$font_family .= ', cursive';
	}
	else {
		$font_family .= ', '.$font['category'];
	}

	return $font_family;
}

/*
 returns the fallback font-family for a particular font
 $font_id: the font as the key in the fonts list.

function lander_get_font_family($font_id){
	$font = lander_get_font($font_id);
	//$font_stack = 'cursive'; 
return '';
}
*/

/*
 returns the huge fonts list.
*/
function lander_get_super_fonts(){
	
	if(1 || !get_transient('lander_fonts_list')){
		//llog('<h1>'.getCallingFunctionName().'</h1>');
		$json = array();
		if(file_exists(CHILD_DIR.'/fonts/g-web-fonts.json')){
			$json = file_get_contents(CHILD_DIR.'/fonts/g-web-fonts.json');
			$json = json_decode($json,1);
		}
	$web_fonts = array();
	foreach ( $json['items'] as $item ) {
		
		$urls = array();

		// Get font properties from json array.
		foreach ( $item['variants'] as $variant ) {

			$name = str_replace( ' ', '+', $item['family'] );
			$urls[ $variant ] = "https://fonts.googleapis.com/css?family={$name}:{$variant}";

		}

		$atts = array( 
			'name'         => $item['family'],
			'category'     => $item['category'],
			'font_type'    => 'google',
			'font_weights' => $item['variants'],
			'subsets'      => $item['subsets'],
			'files'        => $item['files'],
			'urls'         => $urls
		);

		// Add this font to the fonts array
		$id				= strtolower( str_replace( ' ', '_', $item['family'] ) );
		$web_fonts[ $id ]	= $atts;

	}


	// Declare default font list
	$websafe_list = array(
		'inherit'             => array( 'weights' => array( '400'),'category' => 'inherit' ),
		'Arial'               => array( 'weights' => array( '400', '400italic', '700', '700italic' ), 'category' => 'sans-serif' ),
		'Century Gothic'      => array( 'weights' => array( '400', '400italic', '700', '700italic' ), 'category' => 'sans-serif' ),
		'Courier New'         => array( 'weights' => array( '400', '400italic', '700', '700italic' ), 'category' => 'monospace' ),
		'Georgia'             => array( 'weights' => array( '400', '400italic', '700', '700italic' ), 'category' => 'serif' ),
		'Helvetica'           => array( 'weights' => array( '400', '400italic', '700', '700italic' ), 'category' => 'sans-serif' ),
		'Impact'              => array( 'weights' => array( '400', '400italic', '700', '700italic' ), 'category' => 'sans-serif' ),
		'Lucida Console'      => array( 'weights' => array( '400', '400italic', '700', '700italic' ), 'category' => 'monospace' ),
		'Lucida Sans Unicode' => array( 'weights' => array( '400', '400italic', '700', '700italic' ), 'category' => 'sans-serif' ),
		'Palatino Linotype'   => array( 'weights' => array( '400', '400italic', '700', '700italic' ), 'category' => 'serif' ),
		'Tahoma'              => array( 'weights' => array( '400', '400italic', '700', '700italic' ), 'category' => 'sans-serif' ),
		'Times New Roman'        => array( 'weights' => array( '400', '400italic', '700', '700italic' ), 'category' => 'serif' ),
		'Trebuchet MS'        => array( 'weights' => array( '400', '400italic', '700', '700italic' ), 'category' => 'sans-serif' ),
		'Verdana'             => array( 'weights' => array( '400', '400italic', '700', '700italic' ), 'category' => 'sans-serif' ),
	);

	// Build font list to return
	$websafe_fonts = array();
	foreach ( $websafe_list as $font => $attributes ) {

		$urls = array();

		// Get font properties from json array.
		foreach ( $attributes['weights'] as $variant ) {
			//$urls[ $variant ] = "";
		}
		

		// Create a font array containing it's properties and add it to the $websafe_fonts array
		$atts = array(
			'name'         => $font,
			'font_type'    => 'default',
			'category'     => $attributes['category'],
			'font_weights' => $attributes['weights'],
			'subsets'      => array(),
			'files'        => array(),
			//'urls'         => $urls,
		);

		// Add this font to all of the fonts
		$id           = strtolower( str_replace( ' ', '_', $font ) );
		$websafe_fonts[ $id ] = $atts;
	}
	
	$fontslist = array_merge($websafe_fonts,$web_fonts);
	set_transient('lander_fonts_list',$fontslist,60 * 60 * 24); //Expires in 24 hours
	return $fontslist;
	}
	else{
		return get_transient('lander_fonts_list');
	}
//$json_fonts = json_encode($font_list);
}