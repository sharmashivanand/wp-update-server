<?php

function lander_favicon_settings_menu() {
	global $lander_favicon;
	$lander_favicon = new Lander_Favicon_Settings;
}

class Lander_Favicon_Settings extends Genesis_Admin_Basic {
	
	function __construct() {
		$page_id          = CHILD_SETTINGS_FIELD_BRANDING;
		$menu_ops         = array(
			 'submenu' => array(
				'parent_slug' => __( 'genesis', CHILD_DOMAIN ),
				'page_title' => __( 'Lander Branding', CHILD_DOMAIN ),
				'menu_title' => __( 'Lander Branding', CHILD_DOMAIN ) 
			) 
		);
		$page_ops         = array(
			 'screen_icon' => 'themes' 
		);
		$settings_field   = CHILD_SETTINGS_FIELD_BRANDING;
		$default_settings = array(
			 'icon' => CHILD_URL . '/images/favicon.png',
			'logo' => CHILD_URL . '/images/logo.png' 
		);
		$this->create( $page_id, $menu_ops );
		add_action( 'admin_init', array(
			 $this,
			'upload' 
		) );
	}
	
	function help() {
		
	}
	
	function admin() {
?>
	<div class="wrap">
		<?php
		screen_icon( 'tools' );
?>
		<h2><?php
		echo esc_html( get_admin_page_title() );
?></h2>
		<form enctype="multipart/form-data" method="post" action="<?php
		echo menu_page_url( CHILD_SETTINGS_FIELD_BRANDING, 0 );
?>"><?php
		wp_nonce_field( CHILD_SETTINGS_FIELD_BRANDING );
?>
		<table id="lander-branding-form" class="form-table" style="width:auto;">
			<tbody>
			<tr>
				<th scope="row">
					<p><strong><?php _e('Current Favicon:',CHILD_DOMAIN);?></strong></p>
						<?php
		$settings = lander_favicon();
		if ( !$settings ) {
			$settings = CHILD_URL . '/images/favicon.png';
		} //!$settings
?>
				</th>
				<td>
					<p><img alt="Favicon" src="<?php
		echo $settings . '?t=' . microtime();
?>" /></p>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<p><strong><?php _e('Current Logo:',CHILD_DOMAIN);?></strong></p><p>
						
					</p>
				</th>
				<td><p><?php
		echo lander_logo( true );
?></p>
					<p><img alt="Logo" src="<?php
		echo lander_logo( true ) . '?t=' . microtime();
?>" /></p>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<p><strong><?php
		_e( 'Upload Favicon', CHILD_DOMAIN );
?></strong></p>
				</th>
				<td>
				<p>					
				<input type="file" id="lander-icon" name="lander-icon" />
				<br /><small><em><?php _e('This will delete your previous favicon!',CHILD_DOMAIN);?></em></small>
				</p>
				<p><strong><?php _e('Favicon Specifications &mdash;',CHILD_DOMAIN);?> </strong></p>
				<?php _e('For regular displays only: Must be 32px X 32px and must be of the type',CHILD_DOMAIN);?> <?php echo implode( ', ', lander_media_types() ); ?>.
				</td>
			</tr>
			<tr>
			<th scope="row"><p><strong><?php
		_e( 'Upload Logo', CHILD_DOMAIN );
?></strong></p></th>
			<td>
				<p>					
					<input type="file" id="lander-logo" name="lander-logo" />
					<br /><small><em><?php _e('This will delete your previous logo!',CHILD_DOMAIN);?></em></small>
				</p>
				<?php
		$widths         = array();
		$settings       = get_option( lander_get_design_page_id() );
		$padding        = (int) $settings['col-spacing'];
		$content_w_1col = (int) $settings['column-content-1col'];
		$content_w_2col = (int) $settings['column-content-2col'];
		$sb1_w_2col     = (int) $settings['sidebar-one-2col'];
		$content_w_3col = (int) $settings['column-content-3col'];
		$sb1_w_3col     = (int) $settings['sidebar-one-3col'];
		$sb2_w_3col     = (int) $settings['sidebar-two-3col'];
		$widths[]       = ( $content_w_3col + $sb1_w_3col + $sb2_w_3col + $padding * 4 );
		$widths[]       = ( $content_w_3col + $sb1_w_3col + $padding * 3 );
		$widths[]       = ( $content_w_3col + $padding * 2 );
		$widths[]       = ( $content_w_2col + $sb1_w_2col + $padding * 3 );
		$widths[]       = ( $content_w_2col + $padding * 2 );
		$widths[]       = ( $content_w_1col + $padding * 2 );
?>
				<p><strong><?php _e('Logo Specifications &mdash;',CHILD_DOMAIN);?></strong></p>
				<ol>
				<li><?php printf(__('The image should be at least %dpx wide (the largest column layout). ',CHILD_DOMAIN),2 * max( $widths )); ?></li>
				<li><?php printf(__('The content inside the image should not exceed %dpx (the smallest column layout).',CHILD_DOMAIN), 2 * min( $widths ));?></li>
				<li><?php printf(__('The trademark should be positioned at least %dpx away from the left edge of the image.',CHILD_DOMAIN),$padding);?></li>
				<li><?php _e('The trademark should be vertically centred in the image.',CHILD_DOMAIN);?></li>
				<li><?php _e('To create your logo, please use the default-logo.psd that you received with the purchase.',CHILD_DOMAIN);?></li>
				</ol>
				</td>
			</tr>
			<tr><td></td><td><?php
		submit_button( __( 'Upload', CHILD_DOMAIN ), 'primary large', 'lander-branding-upload', false );
?><br /><br /><span style="font-size:small"><span style="font-weight:bold;"><?php _e('Maximum File Size:',CHILD_DOMAIN);?></span> <?php
		echo ini_get( 'post_max_size' );
?></span><br />
					<span style="font-size:small"><span style="font-weight:bold;"><?php _e('File Types:',CHILD_DOMAIN);?></span> <?php
		echo implode( lander_media_types(), ', ' );
?></span>
					</td></tr>
			<?php
		do_action( 'lander_favicon_form' );
?>
			</tbody>
		</table>
		</form>
	</div>
	<?php
	}
	
	function notices() {
	}
	
	function upload() {
		if ( !isset( $_REQUEST['lander-branding-upload'] ) ) {
			return;
		}
		check_admin_referer( CHILD_SETTINGS_FIELD_BRANDING );
		$res         = '';
		$usr_img_dir = lander_get_res( 'dir' ) . 'img';
		lander_init_path( $usr_img_dir );
		$tmp_icon = $_FILES['lander-icon']['tmp_name'];
		if ( is_uploaded_file( $tmp_icon ) ) {
			$file_parts = pathinfo( $_FILES['lander-icon']['name'] );
			$ext        = $file_parts['extension'];
			$dest       = $usr_img_dir . '/' . 'favicon.' . $ext;
			if ( in_array( $ext, lander_media_types() ) ) {
				lander_remove_favicons();
				$res = move_uploaded_file( $tmp_icon, $dest );
				if ( $res ) {
					$favurl = lander_get_res( 'dirurl' ) . 'img/favicon.' . $ext;
					wp_cache_flush();
					$res = __('Favicon updated. Old favicon purged.',CHILD_DOMAIN);
				}
				else {
					$res = __('Couldn\'t move file.',CHILD_DOMAIN);
					if ( !is_writable( $dest ) ) {
						$res .= __(' Destination is not writable.',CHILD_DOMAIN);
					}
				}
			}
			else {
				$res .= ' '.__('File type not allowed',CHILD_DOMAIN);
			}
		}
		else {
			//$res .= ' '.__('File could not be uploaded.',CHILD_DOMAIN);
		}
		$tmp_logo = $_FILES['lander-logo']['tmp_name'];
		if ( is_uploaded_file( $tmp_logo ) ) {
			$file_parts = pathinfo( $_FILES['lander-logo']['name'] );
			$ext        = $file_parts['extension'];
			$dest       = $usr_img_dir . '/' . 'logo.' . $ext;
			if ( in_array( $ext, lander_media_types() ) ) {
				lander_remove_logos();
				$res = move_uploaded_file( $tmp_logo, $dest );
				if ( $res ) {
					$favurl = lander_get_res( 'dirurl' ) . 'img/logo.' . $ext;
					wp_cache_flush();
					$res = __('Logo updated. Old logo purged.',CHILD_DOMAIN);
				} //$res
				else {
					$res = __('Couldn\'t move file.',CHILD_DOMAIN);
					if ( !is_writable( $dest ) ) {
						$res .= ' '.__('Destination is not writable.',CHILD_DOMAIN);
					}
				}
			}
			else {
				$res .= ' '.__('File type not allowed',CHILD_DOMAIN);
			}
		}
		else {
			//$res .= ' '. __('File could not be uploaded.',CHILD_DOMAIN);
		}
		echo '<div id="message" class="updated"><p><strong>' . $res . '</strong></p></div>';
	}
}

function lander_media_types() {
	return apply_filters( 'lander_media_types', array(
		'png',
		'ico',
		'jpg',
		'gif' 
	) );
}

function lander_favicon( $url = '' ) {
	$icon_types = lander_media_types();
	$fav_dest   = lander_get_res( 'dir' ) . 'img/favicon.';
	
	foreach ( $icon_types as $ext ) {
		if ( file_exists( $fav_dest . $ext ) ) {
			return lander_get_res( 'dirurl' ) . 'img/favicon.' . $ext;
		}
	}
	return false;
}

add_filter( 'genesis_pre_load_favicon', 'lander_favicon' );

function lander_remove_favicons() {
	if ( !WP_Filesystem() ) {
		return;
	}
	global $wp_filesystem;
	$icon_types = lander_media_types();
	foreach ( $icon_types as $icon ) {
		if ( file_exists( lander_get_res( 'dir' ) . 'img/favicon.' . $icon ) ) {
			$wp_filesystem->delete( lander_get_res( 'dir' ) . 'img/favicon.' . $icon );
		}
	}
}

function lander_remove_logos() {
	if ( !WP_Filesystem() ) {
		return;
	}
	global $wp_filesystem;
	$logo_types = lander_media_types();
	foreach ( $logo_types as $logo ) {
		if ( file_exists( lander_get_res( 'dir' ) . 'img/logo.' . $logo ) ) {
			$wp_filesystem->delete( lander_get_res( 'dir' ) . 'img/logo.' . $logo );
		}
	}
}