<?php
if ( !defined( 'SORT_NATURAL' ) ) {
	define( 'SORT_NATURAL', 5 );
}

function lander_font_weights(){
	return array('normal','bold','bolder','lighter','100','200','300','400','500','600','700','800','900');	
}

function lander_get_fonts() {
	$fonts = apply_filters( 'lander_fonts', array(
		 '_inherit' => array(
			 'name' => 'inherit',
			'family' => 'inherit',
			'web_safe' => true,
			'google' => false,
			'monospace' => false 
		),
		/*'antonio' => array(
			'name' => 'Antonio',
			'family' => 'antonio, arial',
			'web_safe' => true,
			'google' => false,
			'monospace' => false 
		),*/
		'arial' => array(
			 'name' => 'Arial',
			'family' => 'Arial, "Helvetica Neue", Helvetica, sans-serif',
			'web_safe' => true,
			'google' => false,
			'monospace' => false 
		),
		'arial_black' => array(
			 'name' => 'Arial Black',
			'family' => '"Arial Black", "Arial Bold", Arial, sans-serif',
			'web_safe' => true,
			'google' => false,
			'monospace' => false 
		),
		'arial_narrow' => array(
			 'name' => 'Arial Narrow',
			'family' => '"Arial Narrow", Arial, "Helvetica Neue", Helvetica, sans-serif',
			'web_safe' => true,
			'google' => false,
			'monospace' => false 
		),
		'courier_new' => array(
			 'name' => 'Courier New',
			'family' => '"Courier New", Courier, Verdana, sans-serif',
			'web_safe' => true,
			'google' => false,
			'monospace' => true 
		),
		'crimson_text' => array(
			 'name' => 'Crimson Text',
			'family' => '"Crimson Text", "Times New Roman", Times, serif',
			'web_safe' => true,
			'google' => true,
			'monospace' => false 
		),
		'dr_sugiyama' => array(
			'name' => 'Dr Sugiyama',
			'family' => '"Dr Sugiyama", script',
			'web_safe' => true,
			'google' => true,
			'monospace' => false 
		),
		'georgia' => array(
			 'name' => 'Georgia',
			'family' => 'Georgia, "Times New Roman", Times, serif',
			'web_safe' => true,
			'google' => false,
			'monospace' => false 
		),
		'times_new_roman' => array(
			 'name' => 'Times New Roman',
			'family' => '"Times New Roman", Times, Georgia, serif',
			'web_safe' => true,
			'google' => false,
			'monospace' => false 
		),
		'trebuchet_ms' => array(
			 'name' => 'Trebuchet MS',
			'family' => '"Trebuchet MS", "Lucida Grande", "Lucida Sans Unicode", "Lucida Sans", Arial, sans-serif',
			'web_safe' => true,
			'google' => false,
			'monospace' => false 
		),
		'verdana' => array(
			 'name' => 'Verdana',
			'family' => 'Verdana, sans-serif',
			'web_safe' => true,
			'google' => false,
			'monospace' => false 
		),
		'american_typewriter' => array(
			 'name' => 'American Typewriter',
			'family' => '"American Typewriter", Georgia, serif',
			'web_safe' => false,
			'google' => false,
			'monospace' => false 
		),
		'andale' => array(
			 'name' => 'Andale Mono',
			'family' => '"Andale Mono", Consolas, Monaco, Courier, "Courier New", Verdana, sans-serif',
			'web_safe' => false,
			'google' => false,
			'monospace' => true 
		),
		'baskerville' => array(
			 'name' => 'Baskerville',
			'family' => 'Baskerville, "Times New Roman", Times, serif',
			'web_safe' => false,
			'google' => false,
			'monospace' => false 
		),
		'bookman_old_style' => array(
			 'name' => 'Bookman Old Style',
			'family' => '"Bookman Old Style", Georgia, "Times New Roman", Times, serif',
			'web_safe' => false,
			'google' => false,
			'monospace' => false 
		),
		'calibri' => array(
			 'name' => 'Calibri',
			'family' => 'Calibri, "Helvetica Neue", Helvetica, Arial, Verdana, sans-serif',
			'web_safe' => false,
			'google' => false,
			'monospace' => false 
		),
		'cambria' => array(
			 'name' => 'Cambria',
			'family' => 'Cambria, Georgia, "Times New Roman", Times, serif',
			'web_safe' => false,
			'google' => false,
			'monospace' => false 
		),
		'candara' => array(
			 'name' => 'Candara',
			'family' => 'Candara, Verdana, sans-serif',
			'web_safe' => false,
			'google' => false,
			'monospace' => false 
		),
		'century_gothic' => array(
			 'name' => 'Century Gothic',
			'family' => '"Century Gothic", "Apple Gothic", Verdana, sans-serif',
			'web_safe' => false,
			'google' => false,
			'monospace' => false 
		),
		'century_schoolbook' => array(
			 'name' => 'Century Schoolbook',
			'family' => '"Century Schoolbook", Georgia, "Times New Roman", Times, serif',
			'web_safe' => false,
			'google' => false,
			'monospace' => false 
		),
		'consolas' => array(
			 'name' => 'Consolas',
			'family' => 'Consolas, "Andale Mono", Monaco, Courier, "Courier New", Verdana, sans-serif',
			'web_safe' => false,
			'google' => false,
			'monospace' => true 
		),
		'constantia' => array(
			 'name' => 'Constantia',
			'family' => 'Constantia, Georgia, "Times New Roman", Times, serif',
			'web_safe' => false,
			'google' => false,
			'monospace' => false 
		),
		'corbel' => array(
			 'name' => 'Corbel',
			'family' => 'Corbel, "Lucida Grande", "Lucida Sans Unicode", Arial, sans-serif',
			'web_safe' => false,
			'google' => false,
			'monospace' => false 
		),
		'franklin_gothic' => array(
			 'name' => 'Franklin Gothic Medium',
			'family' => '"Franklin Gothic Medium", Arial, sans-serif',
			'web_safe' => false,
			'google' => false,
			'monospace' => false 
		),
		'garamond' => array(
			 'name' => 'Garamond',
			'family' => 'Garamond, "Hoefler Text", "Times New Roman", Times, serif',
			'web_safe' => false,
			'google' => false,
			'monospace' => false 
		),
		'gill_sans' => array(
			 'name' => 'Gill Sans',
			'family' => '"Gill Sans MT", "Gill Sans", Calibri, "Trebuchet MS", sans-serif',
			'web_safe' => false,
			'google' => false,
			'monospace' => false 
		),
		'helvetica' => array(
			 'name' => 'Helvetica',
			'family' => '"Helvetica Neue", Helvetica, Arial, sans-serif',
			'web_safe' => false,
			'google' => false,
			'monospace' => false 
		),
		'hoefler' => array(
			 'name' => 'Hoefler Text',
			'family' => '"Hoefler Text", Garamond, "Times New Roman", Times, sans-serif',
			'web_safe' => false,
			'google' => false,
			'monospace' => false 
		),
		'lucida_bright' => array(
			 'name' => 'Lucida Bright',
			'family' => '"Lucida Bright", Cambria, Georgia, "Times New Roman", Times, serif',
			'web_safe' => false,
			'google' => false,
			'monospace' => false 
		),
		'lucida_grande' => array(
			 'name' => 'Lucida Grande',
			'family' => '"Lucida Grande", "Lucida Sans", "Lucida Sans Unicode", sans-serif',
			'web_safe' => false,
			'google' => false,
			'monospace' => false 
		),
		'palatino' => array(
			 'name' => 'Palatino',
			'family' => '"Palatino Linotype", Palatino, Georgia, "Times New Roman", Times, serif',
			'web_safe' => false,
			'google' => false,
			'monospace' => false 
		),
		'rockwell' => array(
			 'name' => 'Rockwell',
			'family' => 'Rockwell, "Arial Black", "Arial Bold", Arial, sans-serif',
			'web_safe' => false,
			'google' => false,
			'monospace' => false 
		),
		'tahoma' => array(
			'name' => 'Tahoma',
			'family' => 'Tahoma, Geneva, Verdana, sans-serif',
			'web_safe' => false,
			'google' => false,
			'monospace' => false 
		) 
	) );
	ksort( $fonts, SORT_NATURAL );
	return $fonts;
}

//returns the font-family for a given font
function lander_fontfamily( $value = 'inherit' ) {
	$font_faces = lander_get_fonts();
	if ( $value == 'inherit' || empty( $value ) ) {
		return 'inherit';
	}
	return $font_faces[$value]['family'];
}

function enqueue_web_fonts(){
//get all active fonts?
	
	//build an array of font settings from the entire design settings
	$fonts = get_option(lander_get_design_page_id());	//get all settings
	$fonts = lander_get_settings_fonts($fonts);	//filter the ones with font-families

	
	$lander_all_fonts = lander_get_fonts();	//get all fonts
	$font_families = array();
	
	//push all font-families in the current settings into an array
	foreach($fonts as $key => $value){
		$font_families[$value] = $lander_all_fonts[$value];
	}
	
	
	//build the script src.
	$font_src = array(); 
	foreach($font_families as $key => $value){
		if($value['google']){
			$font_src[] = $value['name'];
		}
	}
	if(!count($font_src)) {
		return;
	}
	$font_src = implode('|',$font_src);
	wp_enqueue_style( 'lander_web_fonts', 'http://fonts.googleapis.com/css?family='.urlencode($font_src),array() , null, 'all');
}

function lander_get_settings_fonts($settings){
	$font_settings = array();
	foreach($settings as $key => $value) {
		if (preg_match('/font\-family/',$key)){
			$font_settings[$key] = $value;
		}
	}
	return $font_settings;
}

add_action( 'wp_enqueue_scripts', 'enqueue_Web_fonts' );