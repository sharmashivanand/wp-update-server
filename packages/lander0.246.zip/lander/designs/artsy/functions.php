<?php

/* Theme customizations for Artsy — classic artistic Lander μFrameWork design*/

add_action ('wp_head','artsy_font_scripts');

function artsy_font_scripts(){
	echo '<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,600,600italic,700italic,700,400italic,300,300italic|Playfair+Display+SC:400,400italic,700,700italic|Playfair+Display:400,400italic,700,700italic" rel="stylesheet" type="text/css" />';
}

add_filter('lander_fonts','artsy_fonts');

function artsy_fonts($fonts){
$fonts['open_sans'] = array(
			 'name' => 'Open Sans',
			'family' => '"Open Sans", "Helvetica Neue", Helvetica, sans-serif',
			'web_safe' => true,
			'google' => true,
			'monospace' => false 
		);
		$fonts['playfair_display'] = array(
			 'name' => 'Playfair Display',
			'family' => '"Playfair Display", "Times New Roman", serif',
			'web_safe' => true,
			'google' => true,
			'monospace' => false 
		);
		$fonts['playfair_display_sc'] = array(
			 'name' => 'Playfair Display SC',
			'family' => '"Playfair Display SC", "Times New Roman", serif',
			'web_safe' => true,
			'google' => true,
			'monospace' => false 
		);
		return $fonts;
}

add_filter('lander_settings_css','artsy_css',10,3);

function artsy_css ($css,$settings,$widths) {
	$css = $css . 'body.lander .nav-secondary, body.lander .footer-widgets .wrap {background-color: '.$settings['subnav-menu-link-bg-color'].';}';
	$css = $css . 'body.lander .nav-primary {border-bottom: 1px solid '.$settings['nav-menu-border-color'].'; border-top: 1px solid '.$settings['nav-menu-border-color'].';}';
	$css = $css . 'body.lander .pagination .active a, .lander .pagination li a:hover, .lander .archive-pagination li a:hover, .lander .archive-pagination .active a { background-color: '.$settings['subnav-menu-link-bg-color'].';	color: '.$settings['subnav-menu-link-text-color'].';}';
	$css = $css . 'body.lander .footer-widgets {background-color: '.$settings['subnav-menu-link-bg-color'].';}'; 
	$css = $css . 'body.lander .genesis-nav-menu > .rss > a, .lander .genesis-nav-menu > .twitter > a {color: '.$settings['nav-menu-link-text-color'].'; font-weight: '.$settings['nav-menu-font-weight'].';}';
	$css = $css . 'body.lander .genesis-nav-menu > .rss > a:hover, .lander .genesis-nav-menu > .twitter > a:hover {color: '.$settings['nav-menu-link-text-hover-color'].';}';
	$css = $css . 'body.lander .nav-secondary .wrap {background-color: '.$settings['subnav-menu-link-bg-color'].'; background-position: '.$settings['col-spacing'].'px center;}';
	return $css;
}

add_filter('lander_media_queries','artsy_resp_css',10,3);

function artsy_resp_css($resp_css, $widths, $settings) {
	$additional_css_one_zero = 'body.lander.full-width-content .menu-secondary {
		float:left;
		width: 100%;
	}
	body.lander.full-width-content .nav-secondary .wrap {
		background-image: none;
	}
	body.lander.full-width-content .menu-primary li:first-child a {
		padding-left: 1em;
	}
	.lander.full-width-content.pagewidth .site-container {
		box-shadow: none;
	}';
	
	$additional_css_two_zero = 'body.lander.sidebar-content .menu-secondary,
	body.lander.content-sidebar .menu-secondary{
		float:left;
		width: 100%;
	}
	body.lander.sidebar-content .nav-secondary .wrap,
	body.lander.content-sidebar .nav-secondary .wrap{
		background-image: none;
	}
	body.lander.sidebar-content .menu-primary li:first-child a,
	body.lander.content-sidebar .menu-primary li:first-child a {
		padding-left: 1em;
	}
	.lander.sidebar-content.pagewidth .site-container,
	.lander.content-sidebar.pagewidth .site-container {
		box-shadow: none;
	}';
	
	$additional_css_three_zero = 'body.lander.sidebar-content-sidebar .menu-secondary,
	body.lander.content-sidebar-sidebar .menu-secondary,
	body.lander.sidebar-sidebar-content .menu-secondary{
		float:left;
		width: 100%;
	}
	body.lander.sidebar-content-sidebar .nav-secondary .wrap,
	body.lander.content-sidebar-sidebar .nav-secondary .wrap,
	body.lander.sidebar-sidebar-content .nav-secondary .wrap{
		background-image: none;
	}
	body.lander.sidebar-content-sidebar .menu-primary li:first-child a,
	body.lander.content-sidebar-sidebar .menu-primary li:first-child a,
	body.lander.sidebar-sidebar-content .menu-primary li:first-child a {
		padding-left: 1em;
	}
	.lander.sidebar-content-sidebar.pagewidth .site-container,
	.lander.content-sidebar-sidebar.pagewidth .site-container,
	.lander.sidebar-sidebar-content.pagewidth .site-container {
		box-shadow: none;
	}';
	
	$resp_css ['one-zero'] =  $resp_css ['one-zero']  . $additional_css_one_zero;
	$resp_css ['two-zero'] =  $resp_css ['two-zero']  . $additional_css_two_zero;
	$resp_css ['three-zero'] =  $resp_css ['three-zero']  . $additional_css_three_zero;
	
	return $resp_css; 

}

add_filter('lander_design_defaults','artsy_defaults');

function artsy_defaults($defaults){
$defaults['layout']='fullwidth';
$defaults['col-spacing']=40;
$defaults['column-content-1col']=900;
$defaults['column-content-2col']=640;
$defaults['sidebar-one-2col']=220;
$defaults['column-content-3col']=500;
$defaults['sidebar-one-3col']=160;
$defaults['sidebar-two-3col']=160;
$defaults['body-font-family']='open_sans';
$defaults['content-area-font-size']=14;
$defaults['content-area-font-weight']='normal';
$defaults['site-background-color']='#fff';
$defaults['page-background-color']='#ffffff';
$defaults['primary-text-color']='#555';
$defaults['primary-link-color']='#000';
$defaults['primary-link-hover-color']='#808080';
$defaults['header-area-font-color']='#111';
$defaults['header-area-font-size']=54;
$defaults['header-area-font-weight']='normal';
$defaults['header-area-font-family']='playfair_display';
$defaults['header-area-tagline-font-color']='#808080';
$defaults['header-area-tagline-font-size']=14;
$defaults['header-area-tagline-font-weight']='300';
$defaults['header-area-tagline-font-family']='_inherit';
$defaults['headline-font-color']='#333';
$defaults['headline-font-weight']='normal';
$defaults['headline-font-size']=28;
$defaults['headline-font-family']='playfair_display_sc';
$defaults['headline-subhead-font-color']='#333';
$defaults['headline-subhead-font-weight']='normal';
$defaults['headline-subhead-font-family']='playfair_display_sc';
$defaults['nav-menu-font-family']='_inherit';
$defaults['nav-menu-font-size']=13;
$defaults['nav-menu-font-weight']='normal';
$defaults['nav-menu-link-text-color']='#666';
$defaults['nav-menu-link-text-hover-color']='#000';
$defaults['nav-menu-current-link-text-color']='#000';
$defaults['nav-menu-current-parent-link-text-color']='#000';
$defaults['nav-menu-link-bg-color']='#fff';
$defaults['nav-menu-hover-bg-color']='#fff';
$defaults['nav-menu-current-bg-color']='#fff';
$defaults['nav-menu-current-parent-bg-color']='#fff';
$defaults['nav-menu-border-width']=0;
$defaults['nav-menu-border-color']='#ccc';
$defaults['nav-menu-submenu-width']=200;
$defaults['subnav-menu-font-family']='_inherit';
$defaults['subnav-menu-font-size']=11;
$defaults['subnav-menu-font-weight']='600';
$defaults['subnav-menu-link-text-color']='#fff';
$defaults['subnav-menu-link-text-hover-color']='#aaa';
$defaults['subnav-menu-current-link-text-color']='#aaa';
$defaults['subnav-menu-current-parent-link-text-color']='#aaa';
$defaults['subnav-menu-link-bg-color']='#111';
$defaults['subnav-menu-hover-bg-color']='#111';
$defaults['subnav-menu-current-bg-color']='#111';
$defaults['subnav-menu-current-parent-bg-color']='#111';
$defaults['subnav-menu-border-width']=0;
$defaults['subnav-menu-border-color']='#ccc';
$defaults['subnav-menu-submenu-width']=150;
$defaults['byline-font-family']='_inherit';
$defaults['byline-font-color']='#808080';
$defaults['byline-font-size']=12;
$defaults['code-font-color']='#111111';
$defaults['code-font-size']=12;
$defaults['code-font-family']='consolas';
$defaults['sidebar-font-family']='_inherit';
$defaults['sidebar-font-color']='#333';
$defaults['sidebar-font-size']=13;
$defaults['sidebar-font-weight']='normal';
$defaults['sidebar-heading-font-family']='playfair_display_sc';
$defaults['sidebar-heading-font-size']=15;
$defaults['sidebar-heading-font-weight']='normal';
$defaults['sidebar-heading-font-color']='#000';
$defaults['footer-widgets']='enable';
$defaults['footer-widgets-font-family']='_inherit';
$defaults['footer-widgets-font-color']='#aaa';
$defaults['footer-widgets-font-size']=13;
$defaults['footer-widgets-font-weight']='normal';
$defaults['footer-widgets-heading-font-family']='playfair_display_sc';
$defaults['footer-widgets-heading-font-size']=15;
$defaults['footer-widgets-heading-font-weight']='normal';
$defaults['footer-widgets-heading-font-color']='#fff';
$defaults['footer-font-family']='_inherit';
$defaults['footer-font-color']='#555';
$defaults['footer-font-size']=12;
$defaults['footer-font-weight']='normal';
return $defaults;
}